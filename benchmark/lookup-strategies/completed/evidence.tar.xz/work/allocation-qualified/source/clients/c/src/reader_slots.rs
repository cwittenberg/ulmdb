//! LMDB's thread-owned reader slots and MDB_NOTLS transaction-owned slots.
use super::*;
use std::cell::RefCell;
use std::sync::Weak;

pub(super) struct ThreadSlot {
    thread: ThreadId,
    lease: process::ReaderLease,
    active: bool,
}

struct ThreadCleanup(Vec<(Weak<Shared>, ThreadId)>);
impl Drop for ThreadCleanup {
    fn drop(&mut self) {
        for (environment, thread) in &self.0 {
            if let Some(shared) = environment.upgrade()
                && let Ok(mut slots) = shared.reader_threads.lock()
            {
                slots.retain(|slot| slot.thread != *thread);
            }
        }
    }
}
thread_local! {
    static CLEANUP: RefCell<ThreadCleanup> = const { RefCell::new(ThreadCleanup(Vec::new())) };
}

pub(super) fn acquire(
    shared: &Arc<Shared>,
    notls: bool,
    nolock: bool,
    sequence: u64,
    transaction_lease: &mut Option<process::ReaderLease>,
) -> FfiResult<()> {
    if nolock {
        return Ok(());
    }
    if notls {
        if let Some(lease) = transaction_lease {
            lease.update(Some(sequence))?;
        } else {
            *transaction_lease = Some(process::ReaderLease::acquire(shared, sequence)?);
        }
    } else {
        let thread = std::thread::current().id();
        let mut slots = shared.reader_threads.lock().map_err(|_| BAD_TXN)?;
        if let Some(slot) = slots.iter_mut().find(|slot| slot.thread == thread) {
            if slot.active {
                return Err(-30783); // MDB_BAD_RSLOT: this thread already owns a reader.
            }
            slot.lease.update(Some(sequence))?;
            slot.active = true;
        } else {
            let lease = process::ReaderLease::acquire(shared, sequence)?;
            slots.push(ThreadSlot {
                thread,
                lease,
                active: true,
            });
            CLEANUP.with(|cleanup| {
                let mut cleanup = cleanup.borrow_mut();
                cleanup
                    .0
                    .retain(|(environment, _)| environment.strong_count() != 0);
                cleanup.0.push((Arc::downgrade(shared), thread));
            });
        }
    }
    shared
        .readers
        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    Ok(())
}

pub(super) fn release(txn: &mut MDB_txn, finished: bool) {
    if unsafe { (*txn.env).flags() } & 0x400000 != 0 {
        return;
    }
    if txn.notls {
        if finished {
            txn.reader_lease.take();
        } else if let Some(lease) = &mut txn.reader_lease {
            let _ = lease.update(None);
        }
    } else if let Ok(mut slots) = txn.shared.reader_threads.lock()
        && let Some(slot) = slots.iter_mut().find(|slot| slot.thread == txn.thread)
    {
        slot.active = false;
        let _ = slot.lease.update(None);
    }
    txn.shared
        .readers
        .fetch_sub(1, std::sync::atomic::Ordering::Relaxed);
}
