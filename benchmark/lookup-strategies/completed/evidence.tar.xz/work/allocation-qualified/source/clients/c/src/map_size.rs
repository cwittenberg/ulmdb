//! Published logical map capacity for independent LMDB adapter environments.
//! The caller holds the compatibility writer lease while publishing a commit.
use super::{FfiResult, code};
use std::{
    fs::{File, OpenOptions},
    io::{Read, Write},
    path::Path,
    sync::atomic::{AtomicU64, Ordering},
};

const CONFIG: &str = "LMDB-MAPSIZE";

pub(super) fn read(directory: &Path) -> FfiResult<Option<usize>> {
    let path = directory.join(CONFIG);
    match std::fs::symlink_metadata(&path) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(code(error.into())),
        Ok(metadata) if !metadata.is_file() => return Err(-30796),
        Ok(_) => {}
    }
    let mut bytes = Vec::with_capacity(9);
    File::open(path)
        .map_err(|error| code(error.into()))?
        .take(9)
        .read_to_end(&mut bytes)
        .map_err(|error| code(error.into()))?;
    let bytes: [u8; 8] = bytes.try_into().map_err(|_| -30796)?;
    let size = usize::try_from(u64::from_le_bytes(bytes)).map_err(|_| -30796)?;
    if size == 0 {
        return Err(-30796);
    }
    Ok(Some(size))
}

pub(super) fn publish(directory: &Path, size: usize) -> FfiResult<()> {
    if size == 0 {
        return Err(libc::EINVAL);
    }
    if read(directory)?.is_some_and(|published| published >= size) {
        return Ok(());
    }
    let size = u64::try_from(size).map_err(|_| -30792)?;
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let (temporary, mut file) = loop {
        let serial = NEXT
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |value| {
                value.checked_add(1)
            })
            .map_err(|_| -30792)?;
        let path = directory.join(format!(".lmdb-mapsize-{}-{serial}.tmp", std::process::id()));
        match ulmdb_storage::access::options_for_entry(&path)
            .map_err(code)?
            .write(true)
            .create_new(true)
            .open(&path)
        {
            Ok(file) => break (path, file),
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(error) => return Err(code(error.into())),
        }
    };
    let result = (|| -> std::io::Result<()> {
        file.write_all(&size.to_le_bytes())?;
        file.sync_all()?;
        std::fs::rename(&temporary, directory.join(CONFIG))?;
        File::open(directory)?.sync_all()
    })();
    if result.is_err() {
        // Only the private file is ours. If rename succeeded it is absent;
        // never remove the published config after a directory-sync failure.
        let _ = std::fs::remove_file(&temporary);
    }
    result.map_err(|error| code(error.into()))
}
