//! LMDB's public main-cursor catalog is synthesized from native database names.
//! Descriptors stay opaque to applications; native storage remains unchanged.
use super::*;
impl MDB_txn {
    pub(super) fn database_names(&self) -> FfiResult<Vec<Vec<u8>>> {
        match self.state.as_ref() {
            Some(State::Read(r)) => r.database_names(),
            Some(State::PrivateRead(r)) => r.database_names(),
            Some(State::Write(w)) => w.database_names(),
            Some(State::Child(w)) => w.database_names(),
            Some(State::Prepared(_)) | None => return Err(BAD_TXN),
        }
        .map_err(code)
    }
    pub(super) fn main_alias(&self) -> FfiResult<AliasHandle> {
        self.shared
            .handles
            .lock()
            .map_err(|_| BAD_TXN)?
            .get(1)
            .and_then(Option::as_ref)
            .cloned()
            .ok_or(BAD_DBI)
    }
    pub(super) fn native_main_seek(
        &self,
        bound: Option<(&[u8], Option<&[u8]>)>,
        inclusive: bool,
    ) -> FfiResult<Option<(&[u8], &[u8])>> {
        let after = bound.and_then(|(key, value)| value.map(|value| (key, value)));
        let _ = inclusive; // internal callers resume exact stored pairs, never range-seek.
        match self.state.as_ref() {
            Some(State::Read(r)) => r.structural_resume_pair(MAIN, after),
            Some(State::PrivateRead(r)) => r.structural_resume_pair(MAIN, after),
            Some(State::Write(w)) => w.structural_resume_pair(MAIN, after),
            Some(State::Child(w)) => w.structural_resume_pair(MAIN, after),
            _ => return Err(BAD_TXN),
        }
        .or_else(|error| {
            if matches!(error, Error::MissingDatabase) {
                Ok(None)
            } else {
                Err(error)
            }
        })
        .map_err(code)
    }
    pub(super) fn visible_main_empty(&self) -> FfiResult<bool> {
        if self.native_main_seek(None, false)?.is_some() {
            return Ok(false);
        }
        for name in self.database_names()? {
            let actual = self.handle_by_name(&name)?;
            if self.catalog_hidden(NativeId::of(&actual))? {
                continue;
            }
            if self.external_database_name(&name)?.is_some() {
                return Ok(false);
            }
        }
        Ok(true)
    }
    pub(super) fn visible_named(&self, requested: &[u8]) -> FfiResult<alias::VisibleName> {
        // Validate any existing reverse mapping before considering a public
        // capability's known input name. Missing maps never authorize retarget.
        let physical = self.resolve_database_name(requested)?;
        let mut key = requested.to_vec();
        if self.shared.catalog_terminator {
            key.push(0);
        }
        let main = self.main_alias()?;
        if !self.custom_key(&main) && self.db_flags(&main)? & (DUPSORT | 8) == 0 {
            // Default/reverse comparison has exact byte equality. Authenticate
            // the ordinary row first, then resolve a genuine catalog handle;
            // this role needs neither a user-row scan nor row materialization.
            if self.raw_get(MAIN, &key)?.is_some() {
                return Ok(alias::VisibleName::Ordinary);
            }
            return match operations::current_handle(self, &physical) {
                Ok(actual) if self.catalog_hidden(NativeId::of(&actual))? => {
                    Ok(alias::VisibleName::Absent)
                }
                Ok(actual) => Ok(alias::VisibleName::Named(actual)),
                Err(Error::MissingDatabase) => Ok(alias::VisibleName::Absent),
                Err(error) => Err(code(error)),
            };
        }
        let mut previous = None;
        loop {
            let Some((stored, value)) = self.native_main_seek(previous, false)? else {
                break;
            };
            if self.key_order(&main, stored, &key).is_eq() {
                return Ok(alias::VisibleName::Ordinary);
            }
            previous = Some((stored, Some(value)));
        }
        for name in self.database_names()? {
            let actual = self.handle_by_name(&name)?;
            if self.catalog_hidden(NativeId::of(&actual))? {
                continue;
            }
            let Some(mut external) = self.external_database_name(&name)? else {
                continue;
            };
            if self.shared.catalog_terminator {
                external.push(0);
            }
            if self.key_order(&main, &external, &key).is_eq() {
                return Ok(alias::VisibleName::Named(actual));
            }
        }
        Ok(alias::VisibleName::Absent)
    }
    pub(super) fn catalog_handle_for_key(&self, key: &[u8]) -> FfiResult<Option<DatabaseHandle>> {
        match self.catalog_handle_for_key_unmasked(key)? {
            Some(actual) if self.catalog_hidden(NativeId::of(&actual))? => Ok(None),
            result => Ok(result),
        }
    }
    pub(super) fn catalog_handle_for_key_unmasked(
        &self,
        key: &[u8],
    ) -> FfiResult<Option<DatabaseHandle>> {
        let main = self.main_alias()?;
        for name in self.database_names()? {
            let Some(mut external) = self.external_database_name(&name)? else {
                continue;
            };
            if self.shared.catalog_terminator {
                external.push(0);
            }
            if self.key_order(&main, &external, key).is_eq() {
                return self.handle_by_name(&name).map(Some);
            }
        }
        Ok(None)
    }
    pub(super) fn missing_named_code(&self, alias: &AliasHandle) -> FfiResult<c_int> {
        if alias.is_main() {
            return Ok(NOTFOUND);
        }
        if self
            .shared
            .rollback_invalid
            .lock()
            .map_err(|_| BAD_TXN)?
            .contains(&alias.native_id())
        {
            return Ok(BAD_DBI);
        }
        Ok(self
            .shared
            .profile
            .missing_stale(self.visible_main_empty()?))
    }
    pub(super) fn catalog_pairs(&self) -> FfiResult<Vec<Pair>> {
        let mut rows = Vec::new();
        for name in self.database_names()? {
            let Some(external) = self.external_database_name(&name)? else {
                continue;
            };
            let h = self.handle_by_name(&name)?;
            if self.catalog_hidden(NativeId::of(&h))? {
                continue;
            }
            let mut key = external;
            if self.shared.catalog_terminator {
                key.push(0);
            }
            // MDB_db is private to LMDB; expose its ABI-sized opaque descriptor
            // with the persisted public flags. Physical page addresses are not
            // meaningful in the native multi-file store.
            let mut descriptor = vec![0u8; 8 + 5 * std::mem::size_of::<usize>()];
            descriptor[4..6]
                .copy_from_slice(&(self.native_settings(&h)?.flags as u16).to_ne_bytes());
            let last = descriptor.len() - std::mem::size_of::<usize>();
            descriptor[last..].copy_from_slice(&usize::MAX.to_ne_bytes());
            rows.push((key, descriptor));
        }
        Ok(rows)
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn mdb_cursor_is_db(cursor: *mut MDB_cursor) -> c_int {
    let result = catch_unwind(AssertUnwindSafe(|| -> FfiResult<bool> {
        let c = unsafe { get_ref(cursor)? };
        let t = unsafe { get_ref(c.txn)? };
        t.live()?;
        if t.peek_handle(c.dbi)?.name() != MAIN {
            return Ok(false);
        }
        let Some((key, _)) = &c.position else {
            return Ok(false);
        };
        Ok(t.catalog_handle_for_key(key)?.is_some())
    }));
    i32::from(matches!(result, Ok(Ok(true))))
}
