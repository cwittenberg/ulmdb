#ifndef ULMDB_H
#define ULMDB_H
#include "lmdb.h"
#ifdef __cplusplus
extern "C" {
#endif
#define ULMDB_KV 0
#define ULMDB_DUPLICATES 1
#define ULMDB_IPV4 4
#define ULMDB_IPV6 6
/* flags: MDB_CREATE. Names are UTF-8 strings; NULL selects the main KV db. */
int ulmdb_dbi_open(MDB_txn *, const char *, unsigned int kind, unsigned int flags, MDB_dbi *);
/* CIDRs must be canonical (no host bits). Values have transaction lifetime. */
int ulmdb_prefix_put(MDB_txn *, MDB_dbi, const char *cidr, const MDB_val *);
int ulmdb_prefix_get(MDB_txn *, MDB_dbi, const char *cidr, MDB_val *);
int ulmdb_prefix_delete(MDB_txn *, MDB_dbi, const char *cidr);
/* matched_cidr is UTF-8 without a trailing NUL, valid until the next longest
 * match call or transaction end. Value follows the ordinary MDB_val lifetime. */
int ulmdb_longest_match(MDB_txn *, MDB_dbi, const char *address, MDB_val *matched_cidr, MDB_val *);
#ifdef __cplusplus
}
#endif
#endif
