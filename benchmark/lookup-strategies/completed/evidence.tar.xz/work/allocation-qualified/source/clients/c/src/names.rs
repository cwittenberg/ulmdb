//! External LMDB names use native names directly up to the native bound. Longer
//! names use collision-checked physical aliases; the reverse map is transactional.
use super::*;
use sha2::{Digest, Sha256};
const ALIAS_PREFIX: &[u8] = b"\0lmdb-name:";
pub(super) fn is_alias(name: &[u8]) -> bool {
    name.starts_with(ALIAS_PREFIX)
}
fn mapping_key(physical: &[u8]) -> Vec<u8> {
    let mut key = b"name:".to_vec();
    key.extend_from_slice(physical);
    key
}
impl MDB_txn {
    pub(super) fn resolve_database_name(&self, external: &[u8]) -> FfiResult<Vec<u8>> {
        if external == MAIN {
            return Ok(MAIN.to_vec());
        }
        let limit = 511;
        if external.is_empty() || external.len() > limit || external.contains(&0) {
            return Err(BAD_VALSIZE);
        }
        if external.len() <= 255 {
            return Ok(external.to_vec());
        }
        let mut physical = ALIAS_PREFIX.to_vec();
        physical.extend_from_slice(&Sha256::digest(external));
        match self.raw_get(compat_features::META, &mapping_key(&physical))? {
            Some(stored) if stored != external => Err(-30796),
            Some(_) => Ok(physical),
            None => match self.handle_by_name(&physical) {
                Ok(_) => Err(-30796),
                Err(NOTFOUND) => Ok(physical),
                Err(e) => Err(e),
            },
        }
    }
    pub(super) fn record_database_name(
        &mut self,
        external: &[u8],
        physical: &[u8],
    ) -> FfiResult<()> {
        if !is_alias(physical) {
            return Ok(());
        }
        if let Some(stored) = self.raw_get(compat_features::META, &mapping_key(physical))? {
            return if stored == external {
                Ok(())
            } else {
                Err(-30796)
            };
        }
        // The database itself must exist before its public name is installed.
        self.handle_by_name(physical)?;
        let writer = self.writer()?;
        if writer.open_database(compat_features::META).is_err() {
            writer
                .create_database(compat_features::META, DatabaseKind::Kv)
                .map_err(code)?;
        }
        writer
            .put(compat_features::META, &mapping_key(physical), external)
            .map_err(code)
    }
    pub(super) fn external_database_name(&self, physical: &[u8]) -> FfiResult<Option<Vec<u8>>> {
        if is_alias(physical) {
            let external = self
                .raw_get(compat_features::META, &mapping_key(physical))?
                .ok_or(-30796)?;
            if external.len() <= 255 || external.len() > 511 || external.contains(&0) {
                return Err(-30796);
            }
            if self.resolve_database_name(external)? != physical {
                return Err(-30796);
            }
            Ok(Some(external.to_vec()))
        } else if physical.first().is_some_and(|b| *b != 0) {
            Ok(Some(physical.to_vec()))
        } else {
            Ok(None)
        }
    }
    pub(super) fn remove_database_name(&mut self, physical: &[u8]) -> FfiResult<()> {
        if !is_alias(physical) {
            return Ok(());
        }
        self.writer()?
            .delete(compat_features::META, &mapping_key(physical))
            .map_err(code)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn corrupted_reverse_mapping_never_opens_another_database() {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let directory = std::env::temp_dir().join(format!(
            "ulmdb-name-collision-{}-{nonce}",
            std::process::id()
        ));
        let path = std::ffi::CString::new(directory.to_str().unwrap()).unwrap();
        let external = vec![b'n'; 300];
        let requested = std::ffi::CString::new(external.clone()).unwrap();
        let mut env = ptr::null_mut();
        let mut txn = ptr::null_mut();
        unsafe {
            assert_eq!(environment::mdb_env_create(&mut env), 0);
            assert_eq!(environment::mdb_env_set_maxdbs(env, 8), 0);
            assert_eq!(environment::mdb_env_open(env, path.as_ptr(), 0, 0o600), 0);
            assert_eq!(
                transaction::mdb_txn_begin(env, ptr::null_mut(), 0, &mut txn),
                0
            );
            let physical = {
                let transaction = &mut *txn;
                let physical = transaction.resolve_database_name(&external).unwrap();
                let writer = transaction.writer().unwrap();
                if writer.open_database(compat_features::META).is_err() {
                    writer
                        .create_database(compat_features::META, DatabaseKind::Kv)
                        .unwrap();
                }
                writer.create_database(&physical, DatabaseKind::Kv).unwrap();
                writer
                    .put(
                        compat_features::META,
                        &mapping_key(&physical),
                        &vec![b'x'; 300],
                    )
                    .unwrap();
                physical
            };
            let mut dbi = 0;
            assert_eq!(
                operations::mdb_dbi_open(txn, requested.as_ptr(), CREATE, &mut dbi),
                -30796
            );
            assert_eq!(
                (&*txn)
                    .raw_get(compat_features::META, &mapping_key(&physical))
                    .unwrap(),
                Some(vec![b'x'; 300].as_slice())
            );
            transaction::mdb_txn_abort(txn);
            environment::mdb_env_close(env);
        }
        std::fs::remove_dir_all(directory).unwrap();
    }
}
