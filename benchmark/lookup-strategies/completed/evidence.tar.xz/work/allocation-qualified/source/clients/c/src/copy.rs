//! Consistent native snapshots behind LMDB's copy entry points.
mod archive;
mod empty;
use super::*;
pub(super) use archive::{
    restore_archive, restore_archive_externally_synchronized_with_transform,
    restore_archive_with_transform,
};
use std::{
    fs::{self, File},
    os::fd::FromRawFd,
    path::{Path, PathBuf},
};
pub(super) const ARCHIVE_MAGIC: &[u8; 8] = b"ULMDBCP\0";

/// Remove only the uniquely created staging directory owned by this operation.
pub(super) struct Staging {
    path: PathBuf,
    owner: PathBuf,
}
impl Staging {
    pub(super) fn path(&self) -> &Path {
        &self.path
    }
    pub(super) fn absent(parent: &Path) -> FfiResult<Self> {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        for _ in 0..1024 {
            let id = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            let owner = parent.join(format!(".ulmdb-copy-{}-{id}", std::process::id()));
            match fs::create_dir(&owner) {
                Ok(()) => {
                    #[cfg(unix)]
                    {
                        use std::os::unix::fs::PermissionsExt;
                        fs::set_permissions(&owner, fs::Permissions::from_mode(0o700))
                            .map_err(|e| code(e.into()))?;
                    }
                    return Ok(Self {
                        path: owner.join("snapshot"),
                        owner,
                    });
                }
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
                Err(e) => return Err(code(e.into())),
            }
        }
        Err(libc::EEXIST)
    }
    pub(super) fn publish(self, target: &Path) -> FfiResult<()> {
        check_target(target)?;
        fs::rename(&self.path, target).map_err(|e| code(e.into()))?;
        let parent = parent(target);
        File::open(parent)
            .and_then(|f| f.sync_all())
            .map_err(|e| code(e.into()))
    }
}
impl Drop for Staging {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.owner);
    }
}
fn parent(path: &Path) -> &Path {
    path.parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."))
}
fn check_target(path: &Path) -> FfiResult<()> {
    match fs::symlink_metadata(path) {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(code(e.into())),
        Ok(metadata) if metadata.file_type().is_dir() => {
            if fs::read_dir(path)
                .map_err(|e| code(e.into()))?
                .next()
                .is_some()
            {
                Err(libc::EEXIST)
            } else {
                Ok(())
            }
        }
        Ok(_) => Err(libc::EEXIST),
    }
}
fn adapter_metadata(source: &Path, target: &Path) -> FfiResult<()> {
    use std::io::{Read, Write};
    for (name, limit) in [("LMDB-ABI", 64usize), ("LMDB-MAPSIZE", 8usize)] {
        let path = source.join(name);
        match fs::symlink_metadata(&path) {
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
            Err(error) => return Err(code(error.into())),
            Ok(metadata) if !metadata.is_file() || metadata.len() > limit as u64 => {
                return Err(-30796);
            }
            Ok(_) => {}
        }
        if name == "LMDB-MAPSIZE" {
            map_size::read(source)?;
        }
        let mut bytes = Vec::with_capacity(limit + 1);
        File::open(&path)
            .map_err(|e| code(e.into()))?
            .take((limit + 1) as u64)
            .read_to_end(&mut bytes)
            .map_err(|e| code(e.into()))?;
        if bytes.len() > limit {
            return Err(-30796);
        }
        let mut output = fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(target.join(name))
            .map_err(|e| code(e.into()))?;
        output.write_all(&bytes).map_err(|e| code(e.into()))?;
        output.sync_all().map_err(|e| code(e.into()))?;
    }
    File::open(target)
        .and_then(|f| f.sync_all())
        .map_err(|e| code(e.into()))
}

fn snapshot(env: &MDB_env, parent: &Path, flags: u32) -> FfiResult<Staging> {
    if flags & !1 != 0 {
        return Err(libc::EINVAL);
    }
    let shared = env.shared.as_ref().ok_or(libc::EINVAL)?;
    let capture = previous::copy_capture::capture(shared, env.flags(), flags & 1 != 0)?;
    // Capture/Visibility/History choose only authenticated metadata/pins. Both
    // complete graph admission and all building happen after Visibility drops.
    let source = capture.admit(shared.read_ahead(), shared.transform.clone())?;
    let empty = match &source {
        previous::copy_capture::AdmittedCopy::View(view) => empty::logical_empty(view.read())?,
        previous::copy_capture::AdmittedCopy::Pair(_) => false,
    };
    let staging = Staging::absent(parent)?;
    match source {
        previous::copy_capture::AdmittedCopy::Pair(pair) => {
            ulmdb::backup::export_file_pair(&pair, &staging.path).map_err(code)?;
        }
        previous::copy_capture::AdmittedCopy::View(view) if empty => {
            let mode = match view.read().file_manifest().map_err(code)?.format_minor {
                2 => ulmdb::PublicationMode::Legacy,
                3 => ulmdb::PublicationMode::Cohort,
                4 => ulmdb::PublicationMode::Indexed,
                _ => return Err(libc::ENOTSUP),
            };
            if shared.external.is_some() {
                ulmdb::backup::create_empty_file_copy_externally_synchronized(
                    &staging.path,
                    mode,
                    view.read().file_manifest().map_err(code)?.page_size,
                    shared.transform.clone(),
                    ulmdb_storage::access::FileAccessContext::open(view.directory())
                        .map_err(code)?
                        .policy(),
                )
                .map_err(code)?;
            } else if shared.transform.is_some() {
                drop(
                    Environment::create_with_file_access(
                        &staging.path,
                        mode,
                        view.read().file_manifest().map_err(code)?.page_size,
                        Default::default(),
                        shared.read_ahead(),
                        shared.transform.clone(),
                        ulmdb_storage::access::FileAccessContext::open(view.directory())
                            .map_err(code)?
                            .policy(),
                    )
                    .map_err(code)?,
                );
            } else {
                ulmdb::backup::create_empty_file_copy_with_access(
                    &staging.path,
                    mode,
                    view.read().file_manifest().map_err(code)?.page_size,
                    None,
                    ulmdb_storage::access::FileAccessContext::open(view.directory())
                        .map_err(code)?
                        .policy(),
                )
                .map_err(code)?;
            }
        }
        previous::copy_capture::AdmittedCopy::View(view) => {
            ulmdb::backup::compact_file_copy(&view, &staging.path).map_err(code)?;
        }
    }
    adapter_metadata(&shared.directory, &staging.path)?;
    Ok(staging)
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mdb_env_copy(env: *mut MDB_env, path: *const c_char) -> c_int {
    unsafe { mdb_env_copy2(env, path, 0) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mdb_env_copy2(
    env: *mut MDB_env,
    path: *const c_char,
    flags: u32,
) -> c_int {
    boundary(|| {
        let env = unsafe { get_ref(env)? };
        let target = unsafe { filesystem_path(path)? };
        check_target(target)?;
        let staging = snapshot(env, parent(target), flags)?;
        staging.publish(target)
    })
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mdb_env_copyfd(env: *mut MDB_env, fd: c_int) -> c_int {
    unsafe { mdb_env_copyfd2(env, fd, 0) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn mdb_env_copyfd2(env: *mut MDB_env, fd: c_int, flags: u32) -> c_int {
    boundary(|| {
        let env = unsafe { get_ref(env)? };
        // Duplicate the descriptor without taking ownership of the caller's fd.
        // Both descriptors share their file position, matching write semantics.
        let duplicated = unsafe { libc::dup(fd) };
        if duplicated < 0 {
            return Err(std::io::Error::last_os_error()
                .raw_os_error()
                .unwrap_or(libc::EBADF));
        }
        let mut output = unsafe { File::from_raw_fd(duplicated) };
        let staging = snapshot(env, &std::env::temp_dir(), flags)?;
        let shared = env.shared.as_ref().ok_or(libc::EINVAL)?;
        archive::write_archive_v2_with_mode(
            &staging.path,
            &mut output,
            shared.transform.clone(),
            shared.external.is_some(),
        )
    })
}
