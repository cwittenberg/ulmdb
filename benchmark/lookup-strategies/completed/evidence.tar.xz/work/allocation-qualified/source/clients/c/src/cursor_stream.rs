//! Cursor query strategies. Byte ordering seeks native indexes directly;
//! alternate LMDB comparators scan native pairs while retaining one candidate.
use super::*;
use std::cmp::Ordering;

type BorrowedPair<'a> = (&'a [u8], &'a [u8]);
type Bound<'a> = Option<(&'a [u8], Option<&'a [u8]>)>;

#[derive(Clone, Copy)]
pub(super) struct Query<'a> {
    pub bound: Bound<'a>,
    pub inclusive: bool,
    pub reverse: bool,
    pub only_key: Option<&'a [u8]>,
    pub exact_value: Option<&'a [u8]>,
}
impl<'a> Query<'a> {
    pub(super) fn edge(reverse: bool) -> Self {
        Self {
            bound: None,
            inclusive: true,
            reverse,
            only_key: None,
            exact_value: None,
        }
    }
    pub(super) fn bounded(
        key: &'a [u8],
        value: Option<&'a [u8]>,
        inclusive: bool,
        reverse: bool,
    ) -> Self {
        Self {
            bound: Some((key, value)),
            inclusive,
            reverse,
            only_key: None,
            exact_value: None,
        }
    }
    pub(super) fn same_key(mut self, key: &'a [u8]) -> Self {
        self.only_key = Some(key);
        self
    }
    pub(super) fn exact_value(mut self, value: &'a [u8]) -> Self {
        self.exact_value = Some(value);
        self
    }
    fn accepts(self, txn: &MDB_txn, handle: &ResolvedAlias, pair: BorrowedPair<'_>) -> bool {
        if self
            .only_key
            .is_some_and(|key| !txn.key_order(handle, pair.0, key).is_eq())
        {
            return false;
        }
        if self
            .exact_value
            .is_some_and(|value| !txn.value_order(handle, pair.1, value).is_eq())
        {
            return false;
        }
        let Some((key, value)) = self.bound else {
            return true;
        };
        let order = txn.key_order(handle, pair.0, key).then_with(|| {
            if matches!(handle.kind(), DatabaseKind::Duplicates { .. }) {
                value.map_or(Ordering::Equal, |value| {
                    txn.value_order(handle, pair.1, value)
                })
            } else {
                Ordering::Equal
            }
        });
        (if self.reverse {
            order.is_lt()
        } else {
            order.is_gt()
        }) || (self.inclusive && order.is_eq())
    }
}

// The Strategy decision is made once per query, outside its native scan loop.
enum SeekStrategy {
    Bytes,
    Comparator,
}
impl SeekStrategy {
    fn choose(txn: &MDB_txn, handle: &ResolvedAlias) -> FfiResult<Self> {
        Ok(if txn.native_order_matches(handle)? {
            Self::Bytes
        } else {
            Self::Comparator
        })
    }
    fn select<'a>(
        &self,
        txn: &'a MDB_txn,
        handle: &ResolvedAlias,
        query: Query<'_>,
    ) -> FfiResult<Option<BorrowedPair<'a>>> {
        match self {
            Self::Bytes => {
                Ok(
                    native_seek(txn, handle, query.bound, query.inclusive, query.reverse)?
                        .filter(|pair| query.accepts(txn, handle, *pair)),
                )
            }
            Self::Comparator => {
                let mut selected = None;
                let mut pair = txn.physical_pair_after(handle, None).map_err(code)?;
                while let Some(candidate) = pair {
                    if query.accepts(txn, handle, candidate)
                        && selected.is_none_or(|previous| {
                            let order = pair_order(txn, handle, candidate, previous);
                            if query.reverse {
                                order.is_gt()
                            } else {
                                order.is_lt()
                            }
                        })
                    {
                        selected = Some(candidate);
                    }
                    pair = txn
                        .physical_pair_after(handle, Some(candidate))
                        .map_err(code)?;
                }
                Ok(selected)
            }
        }
    }
}
fn native_seek<'a>(
    txn: &'a MDB_txn,
    handle: &ResolvedAlias,
    bound: Bound<'_>,
    inclusive: bool,
    reverse: bool,
) -> FfiResult<Option<BorrowedPair<'a>>> {
    let result = txn.seek_database_pair(handle, bound, inclusive, reverse);
    match result {
        Err(Error::MissingDatabase) if handle.name() == MAIN => Ok(None),
        Err(Error::MissingDatabase) => Err(txn.missing_named_code(&handle.alias)?),
        result => result.map_err(code).map(|pair| {
            pair.map(|(key, value)| (key, txn.reserve_value(handle, key).unwrap_or(value)))
        }),
    }
}
fn pair_order(
    txn: &MDB_txn,
    handle: &ResolvedAlias,
    a: BorrowedPair<'_>,
    b: BorrowedPair<'_>,
) -> Ordering {
    txn.key_order(handle, a.0, b.0)
        .then_with(|| txn.value_order(handle, a.1, b.1))
}
fn mapped(value: &[u8]) -> MDB_val {
    MDB_val {
        mv_size: value.len(),
        mv_data: value.as_ptr().cast_mut().cast(),
    }
}

pub(super) enum Selection {
    // Raw output views refer to the transaction's pinned storage. Callers must
    // emit them before any engine mutation, exactly as with ordinary mdb_get.
    Mapped {
        key: MDB_val,
        value: MDB_val,
        position: Pair,
    },
    Catalog(Pair),
}
impl Selection {
    pub(super) fn position(&self) -> &Pair {
        match self {
            Self::Mapped { position, .. } | Self::Catalog(position) => position,
        }
    }
    pub(super) fn output(
        self,
        txn: &mut MDB_txn,
        key: *mut MDB_val,
        value: *mut MDB_val,
    ) -> FfiResult<Pair> {
        match self {
            Self::Mapped {
                key: stored_key,
                value: stored_value,
                position,
            } => {
                *unsafe { get_mut(key)? } = stored_key;
                *unsafe { get_mut(value)? } = stored_value;
                Ok(position)
            }
            Self::Catalog(position) => {
                let retained = position.clone();
                txn.retired_rows.push(vec![retained]);
                let row = &txn.retired_rows.last().unwrap()[0];
                set_value(key, &row.0)?;
                set_value(value, &row.1)?;
                Ok(position)
            }
        }
    }
}
pub(super) fn select(
    txn: &MDB_txn,
    handle: &ResolvedAlias,
    query: Query<'_>,
) -> FfiResult<Option<Selection>> {
    // Refresh the named descriptor once per query, outside comparator scans.
    txn.refresh_view_alias(handle)?;
    let native = SeekStrategy::choose(txn, handle)?.select(txn, handle, query)?;
    let mut catalog = None;
    if handle.name() == MAIN {
        for pair in txn.catalog_pairs()? {
            if query.accepts(txn, handle, (&pair.0, &pair.1))
                && catalog.as_ref().is_none_or(|previous: &Pair| {
                    let order =
                        pair_order(txn, handle, (&pair.0, &pair.1), (&previous.0, &previous.1));
                    if query.reverse {
                        order.is_gt()
                    } else {
                        order.is_lt()
                    }
                })
            {
                catalog = Some(pair);
            }
        }
    }
    match (native, catalog) {
        (Some(native), Some(catalog)) => {
            let order = pair_order(txn, handle, (&catalog.0, &catalog.1), native);
            if if query.reverse {
                order.is_gt()
            } else {
                order.is_lt()
            } {
                return Ok(Some(Selection::Catalog(catalog)));
            }
            Ok(Some(Selection::Mapped {
                key: mapped(native.0),
                value: mapped(native.1),
                position: (native.0.to_vec(), native.1.to_vec()),
            }))
        }
        (Some(native), None) => Ok(Some(Selection::Mapped {
            key: mapped(native.0),
            value: mapped(native.1),
            position: (native.0.to_vec(), native.1.to_vec()),
        })),
        (None, Some(catalog)) => Ok(Some(Selection::Catalog(catalog))),
        (None, None) => Ok(None),
    }
}

pub(super) fn duplicate_count(
    txn: &MDB_txn,
    handle: &ResolvedAlias,
    key: &[u8],
) -> FfiResult<usize> {
    if txn.detached_database(handle.id())?.is_some() {
        let mut count = 0usize;
        let mut previous = None;
        loop {
            let bound = previous
                .map(|value| (key, Some(value)))
                .or(Some((key, None)));
            let Some((stored, value)) = txn
                .seek_database_pair(handle, bound, previous.is_none(), false)
                .map_err(code)?
            else {
                break;
            };
            if stored != key {
                break;
            }
            count = count.checked_add(1).ok_or(-30792)?;
            previous = Some(value);
        }
        return Ok(count);
    }
    let count = txn.count_alias_duplicates(handle, key)?;
    usize::try_from(count).map_err(|_| BAD_VALSIZE)
}

pub(super) fn multiple(
    cursor: &mut MDB_cursor,
    txn: &mut MDB_txn,
    handle: &ResolvedAlias,
    key: *mut MDB_val,
    value: *mut MDB_val,
    op: u32,
) -> FfiResult<()> {
    if txn.db_flags(handle)? & 0x10 == 0 {
        return Err(INCOMPATIBLE);
    }
    let current = match cursor.position.as_ref() {
        Some(position) => position.clone(),
        None if op == 10 => select(txn, handle, Query::edge(false))?
            .ok_or(NOTFOUND)?
            .position()
            .clone(),
        None if op == 18 => select(txn, handle, Query::edge(true))?
            .ok_or(NOTFOUND)?
            .position()
            .clone(),
        None => return Err(libc::EINVAL),
    };
    let width = current.1.len();
    if width == 0 {
        return Err(BAD_VALSIZE);
    }
    let capacity = (txn.shared.page_size.get() - 16) / width;
    if capacity == 0 {
        return Err(BAD_VALSIZE);
    }
    let edge = Query::bounded(&current.0, None, true, false).same_key(&current.0);
    let mut candidate = select(txn, handle, edge)?;
    let mut index = 0usize;
    let mut current_index = None;
    while let Some(row) = candidate {
        if txn
            .value_order(handle, &row.position().1, &current.1)
            .is_eq()
        {
            current_index = Some(index);
            break;
        }
        let position = row.position();
        candidate = select(
            txn,
            handle,
            Query::bounded(&position.0, Some(&position.1), false, false).same_key(&current.0),
        )?;
        index += 1;
    }
    let current_index = current_index.ok_or(NOTFOUND)?;
    let block = match op {
        5 => current_index / capacity,
        10 if cursor.position.is_none() => 0,
        10 => (current_index + 1) / capacity,
        18 => (current_index / capacity).checked_sub(1).ok_or(NOTFOUND)?,
        _ => return Err(libc::EINVAL),
    };
    if op == 10
        && cursor.position.is_some()
        && current_index + 1 >= duplicate_count(txn, handle, &current.0)?
    {
        return Err(NOTFOUND);
    }
    let start = block * capacity;
    let mut next = select(txn, handle, edge)?;
    let mut packed = Vec::with_capacity(capacity * width);
    let mut last = None;
    let mut stored_key = None;
    let mut seen = 0usize;
    while let Some(row) = next {
        let position = row.position();
        if seen >= start {
            if position.1.len() != width {
                return Err(BAD_VALSIZE);
            }
            if stored_key.is_none() {
                stored_key = Some(match &row {
                    Selection::Mapped { key, .. } => *key,
                    Selection::Catalog(_) => return Err(INCOMPATIBLE),
                });
            }
            packed.extend_from_slice(&position.1);
            last = Some(position.clone());
            if packed.len() / width == capacity {
                break;
            }
        }
        next = select(
            txn,
            handle,
            Query::bounded(&position.0, Some(&position.1), false, false).same_key(&current.0),
        )?;
        seen += 1;
    }
    let last = last.ok_or(NOTFOUND)?;
    if !cursor.multiple.is_empty() {
        txn.retired_rows
            .push(vec![(Vec::new(), std::mem::take(&mut cursor.multiple))]);
    }
    cursor.multiple = packed;
    cursor.position = Some(last);
    *unsafe { get_mut(key)? } = stored_key.ok_or(NOTFOUND)?;
    set_value(value, &cursor.multiple)
}
