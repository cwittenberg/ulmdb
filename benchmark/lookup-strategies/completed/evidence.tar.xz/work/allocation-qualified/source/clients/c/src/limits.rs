//! Adapter map-capacity admission, separate from native allocation policies.
use super::*;
impl MDB_txn {
    fn logical_size(&self) -> FfiResult<usize> {
        let mut size = 8192usize;
        for name in self.database_names()? {
            if name != MAIN && !names::is_alias(&name) && name.first().is_some_and(|b| *b == 0) {
                continue;
            }
            let h = self.handle_by_name(&name)?;
            if !matches!(h.kind(), DatabaseKind::Kv | DatabaseKind::Duplicates { .. }) {
                continue;
            }
            size = size.checked_add(name.len() + 48).ok_or(-30792)?;
            fn count<'a>(
                size: &mut usize,
                pairs: impl Iterator<Item = ulmdb::Result<(&'a [u8], &'a [u8])>>,
            ) -> FfiResult<()> {
                for pair in pairs {
                    let (key, value) = pair.map_err(code)?;
                    *size = size
                        .checked_add(key.len())
                        .and_then(|n| n.checked_add(value.len()))
                        .and_then(|n| n.checked_add(16))
                        .ok_or(-30792)?;
                }
                Ok(())
            }
            match self.state.as_ref() {
                Some(State::Read(r)) => count(&mut size, r.structural_pairs(&name).map_err(code)?)?,
                Some(State::PrivateRead(r)) => {
                    count(&mut size, r.structural_pairs(&name).map_err(code)?)?
                }
                Some(State::Write(w)) => {
                    count(&mut size, w.structural_pairs(&name).map_err(code)?)?
                }
                Some(State::Child(w)) => {
                    count(&mut size, w.structural_pairs(&name).map_err(code)?)?
                }
                Some(State::Prepared(_)) | None => return Err(BAD_TXN),
            }
        }
        Ok(size)
    }
    pub(super) fn quota_adjust(&mut self, added: usize, removed: usize) -> FfiResult<()> {
        let used = match self.quota_used {
            Some(size) => size,
            None => self.logical_size()?,
        };
        let next = used
            .saturating_sub(removed)
            .checked_add(added)
            .ok_or(-30792)?;
        let limit = unsafe { get_ref(self.env)? }.mapsize;
        if next > limit {
            self.capacity_failed = true;
            return Err(-30792);
        }
        self.quota_used = Some(next);
        Ok(())
    }
}
