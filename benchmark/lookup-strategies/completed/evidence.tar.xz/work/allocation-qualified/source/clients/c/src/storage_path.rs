//! Logical LMDB paths map to native ULMDB environments. Existing LMDB files
//! are imported by an isolated tool; this module never loads a foreign engine.
use super::*;
use std::{
    fs::{File, OpenOptions},
    io::{Read, Write},
    os::unix::fs::OpenOptionsExt,
    path::{Path, PathBuf},
};
const MARKER: &[u8] = b"ULMDB-LMDB-ADAPTER\n";
pub(super) fn native_path(path: &Path, flags: u32) -> FfiResult<PathBuf> {
    native_path_with_transform(path, flags, None)
}
pub(super) fn native_path_with_transform(
    path: &Path,
    flags: u32,
    transform: Transform,
) -> FfiResult<PathBuf> {
    let no_subdir = flags & 0x4000 != 0;
    let native = if no_subdir {
        let mut value = path.as_os_str().to_owned();
        value.push(".ulmdb");
        PathBuf::from(value)
    } else if path.join(".ulmdb/CURRENT").is_file() || path.join("data.mdb").is_file() {
        path.join(".ulmdb")
    } else {
        path.to_path_buf()
    };
    if native.join("CURRENT").is_file() {
        return Ok(native);
    }
    if no_subdir && path.is_file() {
        let mut magic = [0u8; 8];
        if File::open(path)
            .and_then(|mut f| f.read_exact(&mut magic))
            .is_ok()
            && &magic == copy::ARCHIVE_MAGIC
        {
            if flags & 0x400000 != 0 && cfg!(target_os = "linux") {
                copy::restore_archive_externally_synchronized_with_transform(
                    path, &native, transform,
                )?;
            } else {
                copy::restore_archive_with_transform(path, &native, transform)?;
            }
            return Ok(native);
        }
    }
    let legacy = if no_subdir && path.is_file() {
        let mut header = Vec::with_capacity(MARKER.len());
        File::open(path)
            .and_then(|f| f.take(MARKER.len() as u64).read_to_end(&mut header))
            .map_err(|e| code(e.into()))?;
        if header == MARKER
            || (!header.is_empty() && path.metadata().map_err(|e| code(e.into()))?.len() < 32)
        {
            // A marker without its native sidecar, or a truncated database,
            // must never be turned into an apparently empty environment.
            return Err(-30793);
        }
        !header.is_empty() && header != MARKER
    } else {
        !no_subdir
            && path.join("data.mdb").is_file()
            && path
                .join("data.mdb")
                .metadata()
                .map_err(|e| code(e.into()))?
                .len()
                != 0
    };
    if legacy {
        let migrator = migrator_path().ok_or(libc::ENOENT)?;
        let status = std::process::Command::new(migrator)
            .arg(path)
            .arg(&native)
            .arg("--quiet")
            .status()
            .map_err(|e| code(e.into()))?;
        if !status.success() && !native.join("CURRENT").is_file() {
            return Err(-30793);
        }
    }
    Ok(native)
}
fn migrator_path() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("ULMDB_MIGRATOR") {
        return Some(PathBuf::from(path));
    }
    // Discover the installed package beside the loaded adapter, independently
    // of the application working directory.
    let mut info: libc::Dl_info = unsafe { std::mem::zeroed() };
    if unsafe {
        libc::dladdr(
            super::environment::mdb_env_open as *const () as *const c_void,
            &mut info,
        )
    } != 0
        && !info.dli_fname.is_null()
    {
        let name = unsafe { CStr::from_ptr(info.dli_fname) }.to_string_lossy();
        let candidate = Path::new(name.as_ref())
            .parent()?
            .join("../bin/ulmdb-migrate");
        if candidate.is_file() {
            return Some(candidate);
        }
    }
    let candidate =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/lmdb-ulmdb/bin/ulmdb-migrate");
    candidate.is_file().then_some(candidate)
}
pub(super) fn publish_nosubdir_marker(
    path: &Path,
    flags: u32,
    mode: libc::mode_t,
) -> FfiResult<()> {
    if flags & 0x4000 == 0
        || (path.exists() && path.metadata().map_err(|e| code(e.into()))?.len() != 0)
    {
        return Ok(());
    }
    let mut file = OpenOptions::new()
        .create(true)
        .truncate(false)
        .write(true)
        .mode(mode & 0o777)
        .open(path)
        .map_err(|e| code(e.into()))?;
    file.write_all(MARKER).map_err(|e| code(e.into()))?;
    file.sync_all().map_err(|e| code(e.into()))?;
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    File::open(parent)
        .and_then(|f| f.sync_all())
        .map_err(|e| code(e.into()))
}
