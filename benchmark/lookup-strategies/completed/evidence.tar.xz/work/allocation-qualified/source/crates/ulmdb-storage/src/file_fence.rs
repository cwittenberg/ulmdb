//! Exclusive writer OFD ownership, independent of incidental fork inheritance.
use std::{
    fs::{File, TryLockError},
    ops::Deref,
};

/// Retain this guard (or an `Arc` of it), rather than a duplicated raw File,
/// for every capability that can still write. Read-only owners open independent
/// OFDs. After fork, inherited Environments are not supported for further writes.
/// A foreign child's destructor only closes its copy; it cannot unlock the parent.
#[derive(Debug)]
pub struct WriterFence {
    file: File,
    creator_pid: u32,
}
impl WriterFence {
    pub fn try_lock(file: File) -> Result<Self, TryLockError> {
        file.try_lock()?;
        Ok(Self {
            file,
            creator_pid: std::process::id(),
        })
    }
    #[cfg(test)]
    #[allow(dead_code)] // Shared with packed, whose tests need no fake IO descriptor.
    pub(crate) fn unlocked_for_fault(file: File) -> Self {
        Self {
            file,
            creator_pid: 0,
        }
    }
}
impl Deref for WriterFence {
    type Target = File;
    fn deref(&self) -> &File {
        &self.file
    }
}
impl Drop for WriterFence {
    fn drop(&mut self) {
        if self.creator_pid == std::process::id() {
            // Failure leaves the original close behavior and remains fail-closed
            // if an inherited FD still holds this OFD. Never panic from Drop.
            let _ = self.file.unlock();
        }
    }
}
