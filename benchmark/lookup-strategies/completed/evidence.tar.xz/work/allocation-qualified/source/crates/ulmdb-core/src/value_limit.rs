//! Authenticated file-value envelopes; physical segments remain bounded256MiB.
use crate::storage::{Error, Result};
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ValueLimit(u32);
impl ValueLimit {
    pub const DEFAULT: Self = Self(67_108_864);
    pub const EXTENDED: Self = Self(134_217_728);
    pub const fn new(bytes: usize) -> Result<Self> {
        match bytes {
            67_108_864 => Ok(Self::DEFAULT),
            134_217_728 => Ok(Self::EXTENDED),
            _ => Err(Error::InvalidInput("unsupported file value limit")),
        }
    }
    pub const fn get(self) -> usize {
        self.0 as usize
    }
}
impl Default for ValueLimit {
    fn default() -> Self {
        Self::DEFAULT
    }
}
