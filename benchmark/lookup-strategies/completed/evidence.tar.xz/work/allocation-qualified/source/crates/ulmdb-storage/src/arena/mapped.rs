//! Genuine writer-private file mappings. No published immutable inode is ever
//! mapped writable; all mutation/undo/reserve borrows target this unique file.
use crate::{Error, Result};
use memmap2::{MmapMut, MmapOptions};
use std::{
    fs::{self, File},
    ops::{Deref, DerefMut},
    path::{Path, PathBuf},
};
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MappedFlush {
    Synchronous,
    Asynchronous,
    None,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MappedAllocation {
    pub address: usize,
    pub used: usize,
    pub capacity: usize,
    pub file_inode: u64,
    pub file_device: u64,
    pub flush: MappedFlush,
}
pub(super) struct MappedBytes {
    map: Option<MmapMut>,
    file: File,
    path: PathBuf,
    length: usize,
    capacity: usize,
    flush: MappedFlush,
}
pub(super) enum ArenaBytes {
    Heap(Vec<u8>),
    File(MappedBytes),
}
impl ArenaBytes {
    pub fn heap() -> Self {
        Self::Heap(vec![0; 4096])
    }
    pub fn mapped(directory: &Path, capacity: usize, flush: MappedFlush) -> Result<Self> {
        if !(4096..=268_435_456).contains(&capacity) || !capacity.is_multiple_of(4096) {
            return Err(Error::InvalidInput(
                "mapped arena capacity must be4096-aligned and <=256MiB",
            ));
        }
        let (path, initial) =
            crate::temporary::create(&directory.join("transactions"), "writemap")?;
        #[cfg(unix)]
        let original = {
            use std::os::unix::fs::MetadataExt;
            let m = initial.metadata()?;
            (m.dev(), m.ino())
        };
        drop(initial);
        let opened = (|| {
            let mut options = fs::OpenOptions::new();
            options.read(true).write(true);
            #[cfg(unix)]
            {
                use std::os::unix::fs::OpenOptionsExt;
                options.custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC);
            }
            let file = options.open(&path)?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::MetadataExt;
                let m = file.metadata()?;
                if (m.dev(), m.ino()) != original {
                    return Err(Error::Corrupt("mapped private inode replaced"));
                }
            }
            file.set_len(capacity as u64)?;
            // SAFETY: the unique engine-owned staging inode is never published
            // or concurrently changed. Its extent is established before mmap;
            // capacity remains fixed until the mapping is consumed/unmapped.
            #[allow(unsafe_code)]
            let map = unsafe { MmapOptions::new().len(capacity).map_mut(&file)? };
            Ok(Self::File(MappedBytes {
                map: Some(map),
                file,
                path: path.clone(),
                length: 4096,
                capacity,
                flush,
            }))
        })();
        if opened.is_err() {
            let _ = fs::remove_file(path);
        }
        opened
    }
    pub fn mapping(&self) -> Result<Option<MappedAllocation>> {
        match self {
            Self::Heap(_) => Ok(None),
            Self::File(m) => {
                #[cfg(unix)]
                {
                    use std::os::unix::fs::MetadataExt;
                    let meta = m.file.metadata()?;
                    Ok(Some(MappedAllocation {
                        address: m.map.as_ref().unwrap().as_ptr() as usize,
                        used: m.length,
                        capacity: m.capacity,
                        file_inode: meta.ino(),
                        file_device: meta.dev(),
                        flush: m.flush,
                    }))
                }
                #[cfg(not(unix))]
                {
                    Err(Error::InvalidInput("mapped writer platform unsupported"))
                }
            }
        }
    }
    pub fn set_flush(&mut self, flush: MappedFlush) {
        if let Self::File(m) = self {
            m.flush = flush;
        }
    }
    pub fn effective_policy(&self, policy: crate::Durability) -> crate::Durability {
        match self {
            Self::File(m) if m.flush != MappedFlush::Synchronous => crate::Durability::NoSync,
            _ => policy,
        }
    }
    pub fn is_mapped(&self) -> bool {
        matches!(self, Self::File(_))
    }
    pub fn capacity_limit(&self) -> usize {
        match self {
            Self::Heap(_) => 268_435_456,
            Self::File(m) => m.capacity,
        }
    }
    pub fn try_reserve(&mut self, additional: usize) -> Result<()> {
        match self {
            Self::Heap(v) => v.try_reserve(additional).map_err(|_| Error::LimitExceeded),
            Self::File(m) => {
                if m.length
                    .checked_add(additional)
                    .is_some_and(|n| n <= m.capacity)
                {
                    Ok(())
                } else {
                    Err(Error::LimitExceeded)
                }
            }
        }
    }
    pub fn resize(&mut self, length: usize, value: u8) -> Result<()> {
        self.try_reserve(length.saturating_sub(self.len()))?;
        match self {
            Self::Heap(v) => v.resize(length, value),
            Self::File(m) => {
                if length > m.length {
                    m.map.as_mut().unwrap()[m.length..length].fill(value);
                }
                m.length = length;
            }
        }
        Ok(())
    }
    pub fn extend_from_slice(&mut self, bytes: &[u8]) -> Result<()> {
        self.try_reserve(bytes.len())?;
        match self {
            Self::Heap(v) => v.extend_from_slice(bytes),
            Self::File(m) => {
                let end = m.length + bytes.len();
                m.map.as_mut().unwrap()[m.length..end].copy_from_slice(bytes);
                m.length = end;
            }
        }
        Ok(())
    }
    pub fn truncate(&mut self, length: usize) {
        match self {
            Self::Heap(v) => v.truncate(length),
            Self::File(m) => m.length = m.length.min(length),
        }
    }
    pub fn as_slice(&self) -> &[u8] {
        self
    }
    pub fn into_vec(self) -> Vec<u8> {
        match self {
            Self::Heap(v) => v,
            Self::File(m) => m.deref().to_vec(),
        }
    }
    #[cfg(test)]
    pub fn clone(&self) -> Vec<u8> {
        self.to_vec()
    }
    pub fn take_mapped(&mut self) -> Option<MappedBytes> {
        if self.is_mapped() {
            match std::mem::replace(self, Self::Heap(Vec::new())) {
                Self::File(m) => Some(m),
                _ => unreachable!(),
            }
        } else {
            None
        }
    }
}
impl Deref for ArenaBytes {
    type Target = [u8];
    fn deref(&self) -> &[u8] {
        match self {
            Self::Heap(v) => v,
            Self::File(m) => m,
        }
    }
}
impl DerefMut for ArenaBytes {
    fn deref_mut(&mut self) -> &mut [u8] {
        match self {
            Self::Heap(v) => v,
            Self::File(m) => m,
        }
    }
}
impl AsRef<[u8]> for ArenaBytes {
    fn as_ref(&self) -> &[u8] {
        self
    }
}
impl Deref for MappedBytes {
    type Target = [u8];
    fn deref(&self) -> &[u8] {
        &self.map.as_ref().unwrap()[..self.length]
    }
}
impl DerefMut for MappedBytes {
    fn deref_mut(&mut self) -> &mut [u8] {
        &mut self.map.as_mut().unwrap()[..self.length]
    }
}
impl MappedBytes {
    pub(super) fn publish_cohort(
        mut self,
        directory: &Path,
        manifest: &crate::Manifest,
        payload: usize,
        policy: crate::Durability,
    ) -> Result<[u8; 32]> {
        use sha2::{Digest, Sha256};
        use std::io::{Seek, SeekFrom, Write};
        let (descriptor, trailer) = crate::cohort::mapped_tail(manifest, payload as u64)?;
        let hash = Sha256::digest(&descriptor).into();
        let legacy = directory
            .join("commits")
            .join(format!("{:032x}.root", manifest.generation));
        crate::cohort::reject_existing_generation(&legacy)?;
        let target = crate::cohort::path(directory, manifest.generation);
        crate::cohort::reject_existing_generation(&target)?;
        // End source reserve/slice authority before changing the mapped extent.
        drop(self.map.take());
        self.file.set_len(payload as u64)?;
        self.file.seek(SeekFrom::Start(payload as u64))?;
        crate::fault_point!("mapped.cohort.before_tail");
        self.file.write_all(&descriptor)?;
        self.file.write_all(&trailer)?;
        let physical = self.file.metadata()?.len();
        // SAFETY: still our unique unpublished writable inode, now at its exact
        // final extent; no live caller holds a mutable/source mapping anymore.
        #[allow(unsafe_code)]
        let mapped = unsafe {
            MmapOptions::new()
                .len(physical as usize)
                .map_mut(&self.file)?
        };
        crate::fault_point!("mapped.before_flush");
        match self.flush {
            MappedFlush::Asynchronous => mapped.flush_async()?,
            MappedFlush::Synchronous if policy.sync_data() => mapped.flush()?,
            _ => {}
        }
        crate::fault_point!("mapped.after_flush");
        drop(mapped);
        let mut permissions = self.file.metadata()?.permissions();
        permissions.set_readonly(true);
        self.file.set_permissions(permissions)?;
        if policy.sync_data() {
            self.file.sync_all()?;
        }
        crate::fault_point!("mapped.before_rename");
        fs::rename(&self.path, &target)?;
        crate::fault_point!("mapped.after_rename");
        if policy.sync_data() {
            File::open(directory.join("cohorts"))?.sync_all()?;
        }
        Ok(hash)
    }
    pub(super) fn publish(mut self, final_path: &Path, policy: crate::Durability) -> Result<()> {
        crate::fault_point!("mapped.before_flush");
        match self.flush {
            MappedFlush::Asynchronous => self
                .map
                .as_ref()
                .unwrap()
                .flush_async_range(0, self.length)?,
            MappedFlush::Synchronous if policy.sync_data() => {
                self.map.as_ref().unwrap().flush_range(0, self.length)?
            }
            _ => {}
        }
        crate::fault_point!("mapped.after_flush");
        // End every mutable mapping before shortening/sealing the backing file.
        drop(self.map.take());
        self.file.set_len(self.length as u64)?;
        let mut permissions = self.file.metadata()?.permissions();
        permissions.set_readonly(true);
        self.file.set_permissions(permissions)?;
        if policy.sync_data() {
            self.file.sync_all()?;
        }
        crate::fault_point!("mapped.before_rename");
        fs::rename(&self.path, final_path)?;
        crate::fault_point!("mapped.after_rename");
        if policy.sync_data() {
            File::open(
                final_path
                    .parent()
                    .ok_or(Error::Corrupt("mapped segment parent"))?,
            )?
            .sync_all()?;
        }
        Ok(())
    }
}
impl Drop for MappedBytes {
    fn drop(&mut self) {
        // Never unlink another inode placed at our old private name.
        if let (Ok(named), Ok(owned)) = (fs::symlink_metadata(&self.path), self.file.metadata()) {
            #[cfg(unix)]
            {
                use std::os::unix::fs::MetadataExt;
                if named.is_file()
                    && !named.file_type().is_symlink()
                    && (named.dev(), named.ino()) == (owned.dev(), owned.ino())
                {
                    let _ = fs::remove_file(&self.path);
                }
            }
        }
    }
}

impl std::fmt::Debug for ArenaBytes {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.as_slice().fmt(f)
    }
}
impl PartialEq<ArenaBytes> for [u8] {
    fn eq(&self, other: &ArenaBytes) -> bool {
        self == other.as_slice()
    }
}
