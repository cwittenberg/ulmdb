//! Shared native/C writer ownership, including independently linked Rust copies.
//!
//! `LMDB-WRITER` is a stable flock inode. Its checked owner record identifies
//! the Linux process and kernel thread before an acquisition returns. A caller
//! callback can therefore never recursively wait for its own lock, even when a
//! second Rust runtime does not share its TLS. Old unrecorded binaries on that
//! same thread are outside this protocol and must be drained before mixed use.
//! This is volatile coordination metadata, not a data durability/publication
//! record. Cooperating participants never replace or directly edit lease paths.

#[cfg(target_os = "linux")]
mod linux {
    use crate::{Error, Result};
    use std::{
        fs::{self, File, OpenOptions, TryLockError},
        marker::PhantomData,
        os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt},
        path::Path,
        rc::Rc,
    };

    const RECORD_BYTES: usize = 32;
    const MAGIC: &[u8; 8] = b"ULMWR001";

    #[derive(Clone, Copy, PartialEq, Eq)]
    struct Owner {
        pid: u32,
        tid: u32,
    }
    impl Owner {
        #[allow(unsafe_code)]
        fn current() -> Result<Self> {
            // SAFETY: gettid takes no arguments and returns this kernel thread's
            // identity; Rust ThreadId is runtime-local and cannot be used here.
            let tid = unsafe { libc::gettid() };
            let tid = u32::try_from(tid).map_err(|_| Error::Corrupt("invalid kernel thread ID"))?;
            if tid == 0 {
                return Err(Error::Corrupt("invalid kernel thread ID"));
            }
            Ok(Self {
                pid: std::process::id(),
                tid,
            })
        }
        fn encode(self) -> [u8; RECORD_BYTES] {
            let mut bytes = [0; RECORD_BYTES];
            bytes[..8].copy_from_slice(MAGIC);
            bytes[8..12].copy_from_slice(&1u32.to_le_bytes());
            bytes[12..16].copy_from_slice(&self.pid.to_le_bytes());
            bytes[16..20].copy_from_slice(&self.tid.to_le_bytes());
            // 20..28 are reserved, checked zero on decode.
            let checksum = crc(&bytes[..28]);
            bytes[28..].copy_from_slice(&checksum.to_le_bytes());
            bytes
        }
    }
    fn crc(bytes: &[u8]) -> u32 {
        let mut value = !0u32;
        for byte in bytes {
            value ^= u32::from(*byte);
            for _ in 0..8 {
                value = (value >> 1) ^ (0xedb8_8320 & (0u32.wrapping_sub(value & 1)));
            }
        }
        !value
    }
    fn owner(file: &File) -> Result<Option<Owner>> {
        let mut bytes = [0; RECORD_BYTES + 1];
        let length = loop {
            match file.read_at(&mut bytes, 0) {
                Ok(length) => break length,
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(error.into()),
            }
        };
        // Publication starts by truncating; release clears EOF before unlock.
        // An empty/short locked record is therefore an acquisition/release
        // transition before/after caller code. A complete malformed record is
        // corruption, never permission to wait for an unidentified owner.
        if length < RECORD_BYTES {
            return Ok(None);
        }
        if length != RECORD_BYTES
            || &bytes[..8] != MAGIC
            || bytes[8..12] != 1u32.to_le_bytes()
            || bytes[20..28] != [0; 8]
            || bytes[28..32] != crc(&bytes[..28]).to_le_bytes()
        {
            return Err(Error::Corrupt("invalid coordinated writer owner record"));
        }
        let pid = u32::from_le_bytes(bytes[12..16].try_into().unwrap());
        let tid = u32::from_le_bytes(bytes[16..20].try_into().unwrap());
        if pid == 0 || tid == 0 {
            return Err(Error::Corrupt("invalid coordinated writer owner identity"));
        }
        Ok(Some(Owner { pid, tid }))
    }
    fn same_inode(left: &fs::Metadata, right: &fs::Metadata) -> bool {
        left.dev() == right.dev() && left.ino() == right.ino()
    }
    fn validate(directory: &Path, directory_file: &File, file: &File) -> Result<()> {
        let selected_directory = fs::symlink_metadata(directory)?;
        if !selected_directory.is_dir()
            || selected_directory.file_type().is_symlink()
            || !same_inode(&selected_directory, &directory_file.metadata()?)
        {
            return Err(Error::Corrupt("coordinated writer directory was replaced"));
        }
        let selected = fs::symlink_metadata(directory.join("LMDB-WRITER"))?;
        let opened = file.metadata()?;
        if !selected.is_file()
            || selected.file_type().is_symlink()
            || !opened.is_file()
            || selected.nlink() != 1
            || opened.nlink() != 1
            || !same_inode(&selected, &opened)
        {
            return Err(Error::Corrupt("invalid coordinated writer lease inode"));
        }
        if opened.len() > RECORD_BYTES as u64 {
            return Err(Error::Corrupt("oversized coordinated writer owner record"));
        }
        Ok(())
    }

    /// An exclusive writer lease shared by native callers and the C adapter.
    /// Other threads/processes wait; recursive acquisition on the same Linux
    /// kernel thread returns Busy. Retain it through native owner destruction.
    pub struct WriterLease {
        file: File,
        _directory: File,
        creator: u32,
        clear: bool,
        // Like the native writer's MutexGuard, ownership ends on its thread.
        _thread: PhantomData<Rc<()>>,
    }
    impl WriterLease {
        pub fn acquire(directory: impl AsRef<Path>) -> Result<Self> {
            let directory = directory.as_ref();
            let directory_file = OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(directory)?;
            let file = crate::access::options_for_entry(&directory.join("LMDB-WRITER"))?
                .read(true)
                .write(true)
                .create(true)
                .truncate(false)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(directory.join("LMDB-WRITER"))?;
            crate::access::validate_entry(&directory.join("LMDB-WRITER"), &file)?;
            validate(directory, &directory_file, &file)?;
            let current = Owner::current()?;
            let attempted = loop {
                match file.try_lock() {
                    Err(TryLockError::Error(error))
                        if error.kind() == std::io::ErrorKind::Interrupted => {}
                    result => break result,
                }
            };
            match attempted {
                Ok(()) => {}
                Err(TryLockError::WouldBlock) => {
                    if owner(&file)? == Some(current) {
                        return Err(Error::Busy);
                    }
                    loop {
                        match file.lock() {
                            Ok(()) => break,
                            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => {}
                            Err(error) => return Err(error.into()),
                        }
                    }
                }
                Err(TryLockError::Error(error)) => return Err(error.into()),
            }
            // From here every error path explicitly releases the creator's OFD,
            // including when another process inherited an incidental descriptor.
            let mut lease = Self {
                file,
                _directory: directory_file,
                creator: current.pid,
                clear: false,
                _thread: PhantomData,
            };
            validate(directory, &lease._directory, &lease.file)?;
            lease.clear = true;
            // A successful kernel lock supersedes stale or crash-partial state.
            // Complete the new record before any caller can enter its callback.
            lease.file.set_len(0)?;
            lease.file.write_all_at(&current.encode(), 0)?;
            Ok(lease)
        }
    }
    impl Drop for WriterLease {
        fn drop(&mut self) {
            if self.creator == std::process::id() && (!self.clear || self.file.set_len(0).is_ok()) {
                let _ = self.file.unlock();
            }
            // Foreign fork children only close their inherited descriptors.
            // If clearing fails, close rather than explicitly unlock: retaining
            // an inherited OFD is fail-closed until that foreign owner exits.
        }
    }
}

#[cfg(target_os = "linux")]
pub use linux::WriterLease;

#[cfg(not(target_os = "linux"))]
pub struct WriterLease;
#[cfg(not(target_os = "linux"))]
impl WriterLease {
    pub fn acquire(_: impl AsRef<std::path::Path>) -> crate::Result<Self> {
        Err(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "coordinated writer leases are Linux-only",
        )
        .into())
    }
}
