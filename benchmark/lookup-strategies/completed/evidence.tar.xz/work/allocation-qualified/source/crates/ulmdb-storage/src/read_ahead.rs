//! Per-mapping read-ahead request. Advice never changes bytes or ownership.
use crate::{Error, Result};

/// Immutable advice for file-backed mappings owned by an environment.
/// `Random` requests Linux `MADV_RANDOM`; it is a best-effort OS hint, matching
/// LMDB NORDAHEAD. It makes no performance guarantee and is not persisted.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum ReadAhead {
    #[default]
    Normal,
    Random,
}
impl ReadAhead {
    /// Reject unsupported explicit requests before opening or creating files.
    pub fn validate(self) -> Result<()> {
        if self == Self::Random && !cfg!(target_os = "linux") {
            return Err(Error::InvalidInput("random mapping advice is Linux-only"));
        }
        Ok(())
    }
    pub(crate) fn apply(self, bytes: &memmap2::Mmap) {
        #[cfg(target_os = "linux")]
        if self == Self::Random {
            // This is per-VMA advice, not a file/inode-wide fadvise policy.
            // Pinned LMDB ignores advisory errors; retain that best-effort
            // contract. Real kernel acceptance is tested separately.
            let _ = bytes.advise(memmap2::Advice::Random);
        }
        #[cfg(not(target_os = "linux"))]
        let _ = bytes;
    }
}
