//! Negotiated live read capture. Lease inode identity is authenticated by the
//! WAL header; pre-protocol writers cannot decode it. No process-global state.
use crate::{Error, Result};
use sha2::{Digest, Sha256};
use std::os::unix::fs::{FileExt, MetadataExt, OpenOptionsExt};
use std::{
    fs::{self, File, OpenOptions, TryLockError},
    path::{Path, PathBuf},
    sync::Arc,
};
const NAME: &str = "RESIDENT-CAPTURE";
#[derive(Clone, Copy, Debug)]
pub struct CaptureLimits {
    /// Selected logical tail bytes; fixed196608-byte control area is additional.
    pub max_replay_bytes: u64,
    /// Encoded checkpoint file bytes, before hashing/decoding its contents.
    pub max_checkpoint_bytes: u64,
}
impl Default for CaptureLimits {
    fn default() -> Self {
        Self {
            max_replay_bytes: 256 << 20,
            max_checkpoint_bytes: 384 << 20,
        }
    }
}
impl CaptureLimits {
    pub(super) fn validate(self) -> Result<()> {
        if self.max_replay_bytes > 256 << 20 || self.max_checkpoint_bytes > 512 << 20 {
            return Err(Error::InvalidInput("Resident capture byte limit"));
        }
        Ok(())
    }
}
struct Inner {
    directory: PathBuf,
    _directory: File,
    file: File,
    device: u64,
    inode: u64,
    dir_device: u64,
    dir_inode: u64,
    uuid: [u8; 16],
    creator: u32,
}
#[derive(Clone)]
pub(super) struct CaptureGate {
    inner: Arc<Inner>,
}
pub struct ReadCapture {
    guard: GateGuard,
}
pub(super) struct GateGuard {
    file: File,
    gate: CaptureGate,
    creator: u32,
}
fn header(uuid: [u8; 16]) -> [u8; 64] {
    let mut b = [0; 64];
    b[..8].copy_from_slice(b"ULMDBRG1");
    b[8..12].copy_from_slice(&1u32.to_le_bytes());
    b[12..16].copy_from_slice(&64u32.to_le_bytes());
    b[16..32].copy_from_slice(&uuid);
    let mut h = Sha256::new();
    h.update(b"ULMDB/resident/capture-gate/v1\0");
    h.update(&b[..32]);
    b[32..].copy_from_slice(&h.finalize());
    b
}
fn regular(file: &File) -> Result<fs::Metadata> {
    let m = file.metadata()?;
    if !m.is_file() || m.nlink() != 1 {
        return Err(Error::Corrupt("Resident capture gate file kind/link"));
    }
    Ok(m)
}
fn busy(error: TryLockError) -> Error {
    match error {
        TryLockError::WouldBlock => Error::Busy,
        TryLockError::Error(e) => Error::Io(e),
    }
}
impl CaptureGate {
    fn open(directory: &Path, uuid: Option<[u8; 16]>, create: bool) -> Result<Self> {
        #[cfg(not(target_os = "linux"))]
        return Err(Error::InvalidInput(
            "Resident coordinated capture requires Linux",
        ));
        let named = fs::symlink_metadata(directory)?;
        if !named.is_dir() || named.file_type().is_symlink() {
            return Err(Error::Corrupt("Resident capture directory kind"));
        }
        let directory = directory.canonicalize()?;
        let dir = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(&directory)?;
        let dm = dir.metadata()?;
        let path = directory.join(NAME);
        let file = if create {
            crate::access::FileAccessContext::open(&directory)?
                .options()?
                .read(true)
                .write(true)
                .create(true)
                .open(&path)?
        } else {
            match OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&path)
            {
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                    return Err(Error::InvalidInput("Resident capture protocol not enabled"));
                }
                r => r?,
            }
        };
        crate::access::validate_entry(&path, &file)?;
        let m = regular(&file)?;
        let actual = if create {
            uuid.ok_or(Error::InvalidInput("capture gate UUID"))?
        } else {
            let mut b = [0; 64];
            if m.len() != 64 {
                return Err(Error::Corrupt("Resident capture gate width"));
            }
            file.read_exact_at(&mut b, 0)?;
            let id: [u8; 16] = b[16..32].try_into().unwrap();
            if b != header(id) || id == [0; 16] {
                return Err(Error::Corrupt("Resident capture gate identity/hash"));
            }
            id
        };
        let gate = Self {
            inner: Arc::new(Inner {
                directory,
                _directory: dir,
                file,
                device: m.dev(),
                inode: m.ino(),
                dir_device: dm.dev(),
                dir_inode: dm.ino(),
                uuid: actual,
                creator: std::process::id(),
            }),
        };
        gate.check()?;
        Ok(gate)
    }
    pub(super) fn prepare(directory: &Path, uuid: [u8; 16]) -> Result<(Self, GateGuard)> {
        let gate = Self::open(directory, Some(uuid), true)?;
        let guard = gate.lock(false)?;
        let m = gate.inner.file.metadata()?;
        let expected = header(uuid);
        if m.len() > 64 {
            return Err(Error::Corrupt("Resident capture gate width"));
        }
        let mut prior = vec![0; m.len() as usize];
        gate.inner.file.read_exact_at(&mut prior, 0)?;
        if !expected.starts_with(&prior) {
            return Err(Error::Corrupt("Resident capture gate prior identity"));
        }
        if m.len() != 64 {
            guard.file.write_all_at(&expected, 0)?;
            guard.file.set_len(64)?;
            guard.file.sync_all()?;
            gate.inner._directory.sync_all()?;
        }
        guard.check()?;
        Ok((gate, guard))
    }
    pub(super) fn writer(directory: &Path, uuid: [u8; 16], identity: (u64, u64)) -> Result<Self> {
        let gate = Self::open(directory, None, false)?;
        if gate.inner.uuid != uuid || gate.identity() != identity {
            return Err(Error::Corrupt("Resident capture negotiated gate mismatch"));
        }
        Ok(gate)
    }
    pub(super) fn identity(&self) -> (u64, u64) {
        (self.inner.device, self.inner.inode)
    }
    pub(super) fn check(&self) -> Result<()> {
        if self.inner.creator != std::process::id() {
            return Err(Error::InvalidInput("inherited Resident capture gate"));
        }
        let dm = fs::symlink_metadata(&self.inner.directory)?;
        let fm = fs::symlink_metadata(self.inner.directory.join(NAME))?;
        if !dm.is_dir()
            || dm.file_type().is_symlink()
            || dm.dev() != self.inner.dir_device
            || dm.ino() != self.inner.dir_inode
            || !fm.is_file()
            || fm.file_type().is_symlink()
            || fm.nlink() != 1
            || fm.dev() != self.inner.device
            || fm.ino() != self.inner.inode
        {
            return Err(Error::Corrupt("Resident capture namespace changed"));
        }
        Ok(())
    }
    fn lock(&self, shared: bool) -> Result<GateGuard> {
        self.check()?;
        let file = OpenOptions::new()
            .read(true)
            .write(!shared)
            .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(self.inner.directory.join(NAME))?;
        let m = regular(&file)?;
        if (m.dev(), m.ino()) != self.identity() {
            return Err(Error::Corrupt("Resident capture gate replaced"));
        }
        if shared {
            file.try_lock_shared().map_err(busy)?
        } else {
            file.try_lock().map_err(busy)?
        }
        let guard = GateGuard {
            file,
            gate: self.clone(),
            creator: std::process::id(),
        };
        guard.check()?;
        Ok(guard)
    }
    pub(super) fn exclusive(&self) -> Result<GateGuard> {
        self.lock(false)
    }
}
impl ReadCapture {
    pub fn open(directory: impl AsRef<Path>) -> Result<Self> {
        let gate = CaptureGate::open(directory.as_ref(), None, false)?;
        Ok(Self {
            guard: gate.lock(true)?,
        })
    }
    pub fn directory(&self) -> &Path {
        &self.guard.gate.inner.directory
    }
    pub(super) fn uuid(&self) -> [u8; 16] {
        self.guard.gate.inner.uuid
    }
    pub(super) fn check(&self) -> Result<()> {
        self.guard.check()
    }
    pub(super) fn validate_header(&self, b: &[u8]) -> Result<()> {
        let id =
            protocol(b)?.ok_or(Error::InvalidInput("Resident capture protocol not enabled"))?;
        if id != self.guard.gate.identity() {
            return Err(Error::Corrupt("Resident capture WAL gate binding"));
        }
        Ok(())
    }
    pub(super) fn validate_wal(&self, file: &File) -> Result<()> {
        self.check()?;
        let held = regular(file)?;
        let named = fs::symlink_metadata(self.directory().join("RESIDENT.wal"))?;
        if !named.is_file()
            || named.file_type().is_symlink()
            || named.nlink() != 1
            || named.dev() != held.dev()
            || named.ino() != held.ino()
        {
            return Err(Error::Corrupt("Resident captured WAL replaced"));
        }
        Ok(())
    }
    pub(super) fn preflight(
        &self,
        selected_end: u64,
        checkpoint: Option<&Path>,
        limits: CaptureLimits,
    ) -> Result<()> {
        limits.validate()?;
        if selected_end
            .checked_sub(196608)
            .is_none_or(|n| n > limits.max_replay_bytes)
        {
            return Err(Error::LimitExceeded);
        }
        if let Some(p) = checkpoint {
            let m = fs::symlink_metadata(p)?;
            if !m.is_file() || m.file_type().is_symlink() || m.nlink() != 1 {
                return Err(Error::Corrupt("Resident capture checkpoint kind/link"));
            }
            if m.len() > limits.max_checkpoint_bytes {
                return Err(Error::LimitExceeded);
            }
        }
        Ok(())
    }
}
impl GateGuard {
    pub(super) fn check(&self) -> Result<()> {
        if self.creator != std::process::id() {
            return Err(Error::InvalidInput("inherited Resident capture lease"));
        }
        self.gate.check()
    }
}
impl Drop for GateGuard {
    fn drop(&mut self) {
        if self.creator == std::process::id() {
            let _ = self.file.unlock();
        }
    }
}
pub(super) fn protocol(header: &[u8]) -> Result<Option<(u64, u64)>> {
    if header.len() != 256 {
        return Err(Error::Corrupt("Resident capture header width"));
    }
    let flag = u64::from_le_bytes(header[184..192].try_into().unwrap());
    match flag {
        0 => {
            if header[192..208] != [0; 16] {
                return Err(Error::Corrupt("Resident capture unnegotiated identity"));
            }
            Ok(None)
        }
        1 => {
            let dev = u64::from_le_bytes(header[192..200].try_into().unwrap());
            let ino = u64::from_le_bytes(header[200..208].try_into().unwrap());
            if ino == 0 {
                return Err(Error::Corrupt("Resident capture zero gate inode"));
            }
            Ok(Some((dev, ino)))
        }
        _ => Err(Error::Corrupt("Resident capture protocol version")),
    }
}
pub(super) fn negotiated(mut h: [u8; 256], identity: (u64, u64)) -> [u8; 256] {
    h[184..192].copy_from_slice(&1u64.to_le_bytes());
    h[192..200].copy_from_slice(&identity.0.to_le_bytes());
    h[200..208].copy_from_slice(&identity.1.to_le_bytes());
    let mut sum = Sha256::new();
    sum.update(b"ULMDB/resident/capture-WAL-header/v1\0");
    sum.update(&h[..224]);
    h[224..].copy_from_slice(&sum.finalize());
    h
}
pub(super) fn finish<T>(
    result: Result<T>,
    guard: Option<&GateGuard>,
    poisoned: &mut bool,
) -> Result<T> {
    if let Some(g) = guard {
        if let Err(error) = g.check() {
            if result.is_ok() || *poisoned {
                *poisoned = true;
                return Err(Error::OutcomeUnknown);
            }
            return Err(error);
        }
    }
    result
}
#[cfg(all(test, target_os = "linux"))]
#[allow(unsafe_code)]
mod tests {
    use super::*;
    #[test]
    fn foreign_fork_drop_keeps_parent_capture_lease() {
        const NAME: &str = "resident::capture::tests::foreign_fork_drop_keeps_parent_capture_lease";
        if crate::history::tests::run_isolated(NAME) {
            return;
        }
        let path = std::env::temp_dir().join(format!(
            "resident-capture-fork-{}",
            crate::new_identity().unwrap()
        ));
        crate::create_layout(&path).unwrap();
        let (gate, exclusive) =
            CaptureGate::prepare(&path, crate::new_identity().unwrap().to_le_bytes()).unwrap();
        drop(exclusive);
        let lease = ReadCapture::open(&path).unwrap();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0);
        if pid == 0 {
            let valid = matches!(
                lease.check(),
                Err(Error::InvalidInput("inherited Resident capture lease"))
            );
            drop(lease);
            unsafe { libc::_exit(if valid { 0 } else { 7 }) }
        }
        let start = std::time::Instant::now();
        let mut status = 0;
        loop {
            let rc = unsafe { libc::waitpid(pid, &mut status, libc::WNOHANG) };
            if rc == pid {
                break;
            }
            assert!(rc >= 0);
            if start.elapsed() > std::time::Duration::from_secs(3) {
                unsafe {
                    libc::kill(pid, libc::SIGKILL);
                    libc::waitpid(pid, &mut status, 0);
                }
                panic!("capture fork control deadline")
            };
            std::thread::sleep(std::time::Duration::from_millis(5));
        }
        assert_eq!(status, 0);
        assert!(
            matches!(gate.exclusive(), Err(Error::Busy)),
            "foreign child must not unlock parent's OFD"
        );
        drop(lease);
        drop(gate.exclusive().unwrap());
        drop(gate);
        std::fs::remove_dir_all(path).unwrap();
        crate::history::tests::worker_completed(NAME);
    }
}
