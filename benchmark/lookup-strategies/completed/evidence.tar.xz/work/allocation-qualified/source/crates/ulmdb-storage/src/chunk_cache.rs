//! Bounded immutable file windows with explicit pointer ownership. A ChunkPin
//! keeps its exact decoded mmap alive; only unpinned LRU entries can be evicted.
//! This capability does not by itself admit a database graph or a namespace.
use crate::{
    Error, Result,
    transform::{self, ObjectKind, TransformContext},
};
use memmap2::{Mmap, MmapMut, MmapOptions};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fs::{File, Metadata},
    ops::Deref,
    os::unix::fs::{FileExt, MetadataExt},
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, Ordering},
    },
};
const PAGE: usize = 4096;

#[derive(Clone, Copy, Debug)]
pub struct Limits {
    /// Actual OS-rounded decoded mmap bytes, including pinned and in-flight maps.
    pub mapped_bytes: u64,
    /// All live windows, including pins and in-flight loaders. This also bounds
    /// index metadata and concurrent decode scratch (less than16KiB per loader).
    pub windows: usize,
    pub chunk_bytes: usize,
    /// A contiguous request crossing chunks gets a real single mmap. Requests
    /// exceeding this bound fail before eviction or allocation.
    pub max_window_bytes: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            mapped_bytes: 64 << 20,
            windows: 256,
            chunk_bytes: 64 << 10,
            max_window_bytes: 16 << 20,
        }
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Stats {
    pub mapped_bytes: u64,
    pub live_windows: usize,
    pub cached_windows: usize,
    pub pinned_windows: usize,
    pub hits: u64,
    pub misses: u64,
    pub evictions: u64,
}
#[derive(Clone, Copy, Debug)]
pub struct ObjectIdentity {
    pub kind: ObjectKind,
    pub id: u128,
    pub length: u64,
    /// SHA-256 of the complete decoded object, independently supplied by its
    /// authenticated manifest; frame checks never substitute for this binding.
    pub hash: [u8; 32],
    pub file_offset: u64,
}
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct FileIdentity {
    dev: u64,
    ino: u64,
    bytes: u64,
    mtime: i64,
    mtime_ns: i64,
    ctime: i64,
    ctime_ns: i64,
}
impl FileIdentity {
    fn of(meta: &Metadata) -> Result<Self> {
        if !meta.is_file() {
            return Err(Error::Corrupt("chunk source is not a regular file"));
        }
        Ok(Self {
            dev: meta.dev(),
            ino: meta.ino(),
            bytes: meta.len(),
            mtime: meta.mtime(),
            mtime_ns: meta.mtime_nsec(),
            ctime: meta.ctime(),
            ctime_ns: meta.ctime_nsec(),
        })
    }
}
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct SourceKey {
    file: FileIdentity,
    kind: u16,
    id: u128,
    length: u64,
    hash: [u8; 32],
    base: u64,
    context: usize,
    advice: u8,
}
/// A read-only descriptor and an independently verified whole-object hash.
/// Source verification streams4KiB frames; no whole-object mapping is created.
/// Callers retain the ordinary immutable-source/namespace ownership contract.
pub struct AuthenticatedFile {
    file: File,
    key: SourceKey,
    header: Option<[u8; 128]>,
    context: Option<Arc<TransformContext>>,
    read_ahead: crate::ReadAhead,
}
impl AuthenticatedFile {
    pub fn open(
        file: File,
        identity: ObjectIdentity,
        context: Option<Arc<TransformContext>>,
    ) -> Result<Arc<Self>> {
        Self::open_with_read_ahead(file, identity, context, crate::ReadAhead::Normal)
    }
    pub fn open_with_read_ahead(
        file: File,
        identity: ObjectIdentity,
        context: Option<Arc<TransformContext>>,
        read_ahead: crate::ReadAhead,
    ) -> Result<Arc<Self>> {
        read_ahead.validate()?;
        if identity.length == 0 || identity.length > 268_435_456 {
            return Err(Error::LimitExceeded);
        }
        let physical = FileIdentity::of(&file.metadata()?)?;
        let physical_length = match &context {
            Some(c) => c.encoded_length(identity.length)?,
            None => identity.length,
        };
        if identity
            .file_offset
            .checked_add(physical_length)
            .is_none_or(|n| n > physical.bytes)
        {
            return Err(Error::Corrupt("chunk source extent"));
        }
        let header = context
            .as_ref()
            .map(|c| {
                c.checked_object_header(
                    &file,
                    identity.file_offset,
                    identity.kind,
                    identity.id,
                    identity.length,
                )
            })
            .transpose()?;
        let source = Arc::new(Self {
            file,
            key: SourceKey {
                file: physical,
                kind: identity.kind as u16,
                id: identity.id,
                length: identity.length,
                hash: identity.hash,
                base: identity.file_offset,
                context: context.as_ref().map_or(0, |c| Arc::as_ptr(c) as usize),
                advice: u8::from(read_ahead == crate::ReadAhead::Random),
            },
            header,
            context,
            read_ahead,
        });
        let mut digest = Sha256::new();
        let mut page = [0; PAGE];
        let mut scratch = source
            .context
            .as_ref()
            .map(|c| transform::FrameScratch::new(c));
        for start in (0..identity.length).step_by(PAGE) {
            let count = (identity.length - start).min(PAGE as u64) as usize;
            source.frame(start, &mut page[..count], scratch.as_mut())?;
            digest.update(&page[..count]);
        }
        if <[u8; 32]>::from(digest.finalize()) != identity.hash {
            return Err(Error::Corrupt("chunk source hash"));
        }
        source.check()?;
        Ok(source)
    }
    pub fn length(&self) -> u64 {
        self.key.length
    }
    pub(crate) fn validate_extent(&self, offset: u64, length: usize) -> Result<()> {
        self.check()?;
        if offset
            .checked_add(length as u64)
            .is_none_or(|n| n > self.length())
        {
            return Err(Error::Corrupt("chunk read bounds"));
        }
        Ok(())
    }
    fn check(&self) -> Result<()> {
        if FileIdentity::of(&self.file.metadata()?)? != self.key.file {
            return Err(Error::Corrupt("chunk source changed"));
        }
        Ok(())
    }
    fn frame(
        &self,
        start: u64,
        destination: &mut [u8],
        scratch: Option<&mut transform::FrameScratch>,
    ) -> Result<()> {
        if let Some(context) = &self.context {
            transform::decode_frame(
                context,
                &self.file,
                self.key.base,
                self.header.as_ref().unwrap(),
                start / PAGE as u64,
                destination,
                scratch.unwrap(),
            )
        } else {
            self.file
                .read_exact_at(destination, self.key.base + start)
                .map_err(Into::into)
        }
    }
    fn window(&self, start: u64, length: usize) -> Result<(Mmap, Option<transform::DecodedLease>)> {
        self.check()?;
        if self.context.is_none() {
            let at = self
                .key
                .base
                .checked_add(start)
                .ok_or(Error::LimitExceeded)?;
            // SAFETY: callers own the immutable-file contract. Hash/identity
            // verification bound this exact descriptor and bounded prefix.
            // Every pin owns its mmap; eviction cannot revoke live bytes.
            #[allow(unsafe_code)]
            let map = unsafe { MmapOptions::new().offset(at).len(length).map(&self.file)? };
            self.read_ahead.apply(&map);
            self.check()?;
            return Ok((map, None));
        }
        let lease = self
            .context
            .as_ref()
            .map(|c| c.reserve_cache_mapping(length as u64))
            .transpose()?;
        let mut map = MmapMut::map_anon(length)?;
        let mut scratch = self
            .context
            .as_ref()
            .map(|c| transform::FrameScratch::new(c));
        for index in (0..length).step_by(PAGE) {
            let count = (length - index).min(PAGE);
            self.frame(
                start + index as u64,
                &mut map[index..index + count],
                scratch.as_mut(),
            )?;
        }
        self.check()?;
        let map = map.make_read_only()?;
        self.read_ahead.apply(&map);
        Ok((map, lease))
    }
    fn window_charge(&self, start: u64, length: usize) -> Result<u64> {
        let prefix = if self.context.is_none() {
            let page = crate::residency::os::page_size()? as u64;
            self.key
                .base
                .checked_add(start)
                .ok_or(Error::LimitExceeded)?
                % page
        } else {
            0
        };
        TransformContext::mapped_charge(
            (length as u64)
                .checked_add(prefix)
                .ok_or(Error::LimitExceeded)?,
        )
    }
}
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct Key {
    source: SourceKey,
    start: u64,
    length: usize,
}
struct Counts {
    bytes: u64,
    windows: usize,
}
struct Budget {
    limits: Limits,
    used: Mutex<Counts>,
}
struct Charge {
    budget: Arc<Budget>,
    bytes: u64,
}
impl Budget {
    fn reserve(self: &Arc<Self>, bytes: u64) -> Result<Charge> {
        let mut used = self.used.lock().map_err(|_| Error::Busy)?;
        let total = used.bytes.checked_add(bytes).ok_or(Error::LimitExceeded)?;
        if total > self.limits.mapped_bytes || used.windows >= self.limits.windows {
            return Err(Error::LimitExceeded);
        }
        used.bytes = total;
        used.windows += 1;
        Ok(Charge {
            budget: self.clone(),
            bytes,
        })
    }
}
impl Drop for Charge {
    fn drop(&mut self) {
        let mut used = self
            .budget
            .used
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        used.bytes -= self.bytes;
        used.windows -= 1;
    }
}
struct Window {
    map: Mmap,
    _decoded: Option<transform::DecodedLease>,
    _charge: Charge,
}
struct Entry {
    window: Arc<Window>,
    used: u64,
}
struct State {
    entries: BTreeMap<Key, Entry>,
    clock: u64,
}
pub struct ChunkCache {
    limits: Limits,
    budget: Arc<Budget>,
    state: Mutex<State>,
    hits: AtomicU64,
    misses: AtomicU64,
    evictions: AtomicU64,
}
/// The cache may be dropped while pins remain live. Charges, decoded callback
/// owners and the mmap survive until the final pin releases the actual bytes.
#[derive(Clone)]
pub struct ChunkPin {
    window: Option<Arc<Window>>,
    start: usize,
    length: usize,
}
impl ChunkPin {
    /// Process-local deduplication identity only. Keeping any pin alive prevents
    /// address reuse; this does not confer source or snapshot authority.
    pub(crate) fn window_identity(&self) -> Option<usize> {
        self.window
            .as_ref()
            .map(|window| Arc::as_ptr(window) as usize)
    }
}
impl Deref for ChunkPin {
    type Target = [u8];
    fn deref(&self) -> &[u8] {
        self.window
            .as_ref()
            .map_or(&[], |w| &w.map[self.start..self.start + self.length])
    }
}
impl ChunkCache {
    pub fn new(limits: Limits) -> Result<Arc<Self>> {
        let page = crate::residency::os::page_size()?;
        if limits.windows == 0
            || limits.windows > 65_536
            || limits.chunk_bytes == 0
            || !limits.chunk_bytes.is_multiple_of(PAGE)
            || !limits.chunk_bytes.is_multiple_of(page)
            || limits.max_window_bytes < limits.chunk_bytes
            || limits.max_window_bytes > 268_435_456
            || limits.mapped_bytes < page as u64
            || !limits.mapped_bytes.is_multiple_of(page as u64)
        {
            return Err(Error::InvalidInput("chunk cache limits"));
        }
        Ok(Arc::new(Self {
            limits,
            budget: Arc::new(Budget {
                limits,
                used: Mutex::new(Counts {
                    bytes: 0,
                    windows: 0,
                }),
            }),
            state: Mutex::new(State {
                entries: BTreeMap::new(),
                clock: 0,
            }),
            hits: AtomicU64::new(0),
            misses: AtomicU64::new(0),
            evictions: AtomicU64::new(0),
        }))
    }
    pub fn pin(&self, source: &AuthenticatedFile, offset: u64, length: usize) -> Result<ChunkPin> {
        source.check()?;
        let end = offset
            .checked_add(length as u64)
            .filter(|n| *n <= source.length())
            .ok_or(Error::Corrupt("chunk read bounds"))?;
        if length == 0 {
            return Ok(ChunkPin {
                window: None,
                start: 0,
                length: 0,
            });
        }
        let width = self.limits.chunk_bytes as u64;
        let start = offset / width * width;
        let last = end.checked_add(width - 1).ok_or(Error::LimitExceeded)? / width * width;
        let size =
            usize::try_from(last.min(source.length()) - start).map_err(|_| Error::LimitExceeded)?;
        let charge = source.window_charge(start, size)?;
        if size > self.limits.max_window_bytes || charge > self.limits.mapped_bytes {
            return Err(Error::LimitExceeded);
        }
        let key = Key {
            source: source.key,
            start,
            length: size,
        };
        {
            let mut state = self.state.lock().map_err(|_| Error::Busy)?;
            state.clock = state.clock.wrapping_add(1);
            let clock = state.clock;
            if let Some(entry) = state.entries.get_mut(&key) {
                entry.used = clock;
                self.hits.fetch_add(1, Ordering::Relaxed);
                return Ok(ChunkPin {
                    window: Some(entry.window.clone()),
                    start: (offset - start) as usize,
                    length,
                });
            }
        }
        self.misses.fetch_add(1, Ordering::Relaxed);
        let window = loop {
            let reservation = loop {
                match self.budget.reserve(charge) {
                    Ok(lease) => break lease,
                    Err(Error::LimitExceeded) if self.evict_one()? => continue,
                    Err(error) => return Err(error),
                }
            };
            // No cache mutex is held while callbacks, IO, allocation or destructors run.
            match source.window(start, size) {
                Ok((map, decoded)) => {
                    break Arc::new(Window {
                        map,
                        _decoded: decoded,
                        _charge: reservation,
                    });
                }
                Err(Error::LimitExceeded) => {
                    drop(reservation);
                    if !self.evict_matching(Some(source.key.context))? {
                        return Err(Error::LimitExceeded);
                    }
                }
                Err(error) => return Err(error),
            }
        };
        let mut state = self.state.lock().map_err(|_| Error::Busy)?;
        state.clock = state.clock.wrapping_add(1);
        let clock = state.clock;
        let owner = match state.entries.get_mut(&key) {
            Some(existing) => {
                existing.used = clock;
                existing.window.clone()
            }
            None => {
                state.entries.insert(
                    key,
                    Entry {
                        window: window.clone(),
                        used: clock,
                    },
                );
                window.clone()
            }
        };
        drop(state);
        Ok(ChunkPin {
            window: Some(owner),
            start: (offset - start) as usize,
            length,
        })
    }
    fn evict_one(&self) -> Result<bool> {
        self.evict_matching(None)
    }
    fn evict_matching(&self, context: Option<usize>) -> Result<bool> {
        let removed = {
            let mut state = self.state.lock().map_err(|_| Error::Busy)?;
            let victim = state
                .entries
                .iter()
                .filter(|(key, e)| {
                    context.is_none_or(|c| key.source.context == c)
                        && Arc::strong_count(&e.window) == 1
                })
                .min_by_key(|(_, e)| e.used)
                .map(|(key, _)| *key);
            victim.and_then(|key| state.entries.remove(&key))
        };
        if removed.is_some() {
            self.evictions.fetch_add(1, Ordering::Relaxed);
        }
        let existed = removed.is_some();
        drop(removed);
        Ok(existed)
    }
    pub fn trim_unpinned(&self) -> Result<usize> {
        let mut removed = 0;
        while self.evict_one()? {
            removed += 1;
        }
        Ok(removed)
    }
    pub fn stats(&self) -> Result<Stats> {
        let state = self.state.lock().map_err(|_| Error::Busy)?;
        let used = self.budget.used.lock().map_err(|_| Error::Busy)?;
        Ok(Stats {
            mapped_bytes: used.bytes,
            live_windows: used.windows,
            cached_windows: state.entries.len(),
            pinned_windows: state
                .entries
                .values()
                .filter(|e| Arc::strong_count(&e.window) > 1)
                .count(),
            hits: self.hits.load(Ordering::Relaxed),
            misses: self.misses.load(Ordering::Relaxed),
            evictions: self.evictions.load(Ordering::Relaxed),
        })
    }
}
