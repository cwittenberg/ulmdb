//! Transaction-owned bounded chunk pins. No whole segment mapping is created.
use crate::chunk_cache::{AuthenticatedFile, ChunkCache, ChunkPin, ObjectIdentity};
use crate::{Error, ReadStore, Reference, Result, SegmentEntry};
use std::{
    collections::BTreeMap,
    fs::OpenOptions,
    os::unix::fs::OpenOptionsExt,
    path::Path,
    sync::{Arc, Mutex},
};
#[derive(Clone, Copy, Debug)]
pub struct PinLimits {
    pub sources: usize,
    pub pins: usize,
}
impl Default for PinLimits {
    fn default() -> Self {
        Self {
            sources: 4096,
            pins: 65536,
        }
    }
}
impl PinLimits {
    pub fn validate(self) -> Result<()> {
        if self.sources == 0 || self.sources > 1_048_575 || self.pins == 0 || self.pins > 1_048_576
        {
            return Err(Error::InvalidInput("chunk table limits"));
        }
        Ok(())
    }
}
struct Sources {
    files: BTreeMap<u64, Arc<AuthenticatedFile>>,
    cache: Arc<ChunkCache>,
    limits: PinLimits,
    page_size: ulmdb_core::PageSize,
    value_limit: ulmdb_core::ValueLimit,
}
/// A fresh scope shares authenticated source descriptors/cache, but owns its
/// pins independently. Every returned borrow stays valid until this scope drops.
/// Admission can drop an entire short scope after copying only node metadata.
pub struct ChunkedSegmentTable {
    sources: Arc<Sources>,
    pins: Mutex<BTreeMap<usize, Box<ChunkPin>>>,
}
impl ChunkedSegmentTable {
    pub fn load(
        directory: &Path,
        entries: &[SegmentEntry],
        cache: Arc<ChunkCache>,
        limits: PinLimits,
        page_size: ulmdb_core::PageSize,
        value_limit: ulmdb_core::ValueLimit,
        context: Option<Arc<crate::transform::TransformContext>>,
    ) -> Result<Self> {
        limits.validate()?;
        if entries.len() > limits.sources {
            return Err(Error::LimitExceeded);
        }
        let mut previous = 0;
        let first = entries.first().map_or(0, |e| e.id >> 8);
        for e in entries {
            if e.id <= previous || e.id == u64::MAX {
                return Err(Error::Corrupt("chunk inventory IDs"));
            }
            if (e.id >> 8) - first >= crate::table::MAX_DIRECTORY_CHUNKS {
                return Err(Error::LimitExceeded);
            }
            if !(4096..=268_435_456).contains(&e.length) {
                return Err(Error::Corrupt("chunk segment length"));
            }
            previous = e.id;
        }
        let mut files = BTreeMap::new();
        for e in entries {
            let path = crate::segment_path(directory, e);
            let file = OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&path)?;
            crate::access::validate_entry(&path, &file)?;
            use std::os::unix::fs::MetadataExt;
            let meta = file.metadata()?;
            if !meta.is_file() || meta.nlink() != 1 {
                return Err(Error::Corrupt("chunk segment kind/link"));
            }
            let encoded = context
                .as_ref()
                .map(|c| c.encoded_length(e.length))
                .transpose()?
                .unwrap_or(e.length);
            if (e.cohort == 0 && meta.len() != encoded)
                || (e.cohort != 0
                    && (meta.len() < encoded.checked_add(224).ok_or(Error::LimitExceeded)?
                        || meta.len() > crate::MAX_COHORT_BYTES))
            {
                return Err(Error::Corrupt("chunk segment physical length"));
            }
            let source = AuthenticatedFile::open(
                file,
                ObjectIdentity {
                    kind: crate::transform::ObjectKind::Segment,
                    id: e.id as u128,
                    length: e.length,
                    hash: e.hash,
                    file_offset: 0,
                },
                context.clone(),
            )?;
            {
                let header = cache.pin(&source, 0, 4096)?;
                let features = match &header[10..12] {
                    [1, 0] => 1u64,
                    [2, 0] => 3u64,
                    _ => return Err(Error::Corrupt("chunk segment minor")),
                };
                if &header[..8] != b"ULMDBSEG"
                    || header[8..10] != 0u16.to_le_bytes()
                    || header[12..16] != 128u32.to_le_bytes()
                    || header[16..24] != e.id.to_le_bytes()
                    || header[24..28] != 4096u32.to_le_bytes()
                    || header[28] != 1
                    || header[29..32] != [0; 3]
                    || header[32..40] != 4096u64.to_le_bytes()
                    || header[40..48] != (e.length - 4096).to_le_bytes()
                    || header[48..56] != e.length.to_le_bytes()
                    || header[56..64] != features.to_le_bytes()
                    || header[64..].iter().any(|b| *b != 0)
                {
                    return Err(Error::Corrupt("chunk segment header"));
                }
            }
            files.insert(e.id, source);
        }
        Ok(Self {
            sources: Arc::new(Sources {
                files,
                cache,
                limits,
                page_size,
                value_limit,
            }),
            pins: Mutex::new(BTreeMap::new()),
        })
    }
    pub fn scope(&self) -> Self {
        Self {
            sources: self.sources.clone(),
            pins: Mutex::new(BTreeMap::new()),
        }
    }
    pub fn cache(&self) -> &Arc<ChunkCache> {
        &self.sources.cache
    }
    pub fn pinned_requests(&self) -> Result<usize> {
        Ok(self.pins.lock().map_err(|_| Error::Busy)?.len())
    }
    pub fn value_limit(&self) -> ulmdb_core::ValueLimit {
        self.sources.value_limit
    }
}
impl ReadStore for ChunkedSegmentTable {
    fn page_size(&self) -> usize {
        self.sources.page_size.get()
    }
    fn max_value_size(&self) -> usize {
        self.sources.value_limit.get()
    }
    fn validate_extent(&self,at:Reference,length:usize)->Result<()> {
        if at.offset<4096{return Err(Error::Corrupt("reference targets segment header"))}
        let source=self.sources.files.get(&at.segment).ok_or(Error::Corrupt("unknown chunk segment"))?;
        source.validate_extent(at.offset,length)
    }
    #[allow(unsafe_code)]
    fn read(&self, at: Reference, length: usize) -> Result<&[u8]> {
        if at.offset < 4096 {
            return Err(Error::Corrupt("reference targets segment header"));
        }
        let source = self
            .sources
            .files
            .get(&at.segment)
            .ok_or(Error::Corrupt("unknown chunk segment"))?;
        let _end = at
            .offset
            .checked_add(length as u64)
            .filter(|n| *n <= source.length())
            .ok_or(Error::Corrupt("chunk table read bounds"))?;
        if length == 0 {
            let _ = self.sources.cache.pin(source, at.offset, 0)?;
            return Ok(&[]);
        }
        // The cache authenticates and supplies the exact requested span. Retain one
        // owner per actual Window, so distinct offsets/lengths never accumulate
        // per-query metadata for an already-pinned mmap.
        let pin = self.sources.cache.pin(source, at.offset, length)?;
        let identity = pin
            .window_identity()
            .ok_or(Error::Corrupt("nonempty chunk pin owner"))?;
        let pointer = pin.as_ptr();
        let mut guard = self.pins.lock().map_err(|_| Error::Busy)?;
        if !guard.contains_key(&identity) {
            if guard.len() >= self.sources.limits.pins {
                return Err(Error::LimitExceeded);
            }
            guard.insert(identity, Box::new(pin));
        }
        drop(guard);
        // SAFETY: arena owners are append-only and never removed/replaced. The
        // Window identity is its Arc allocation address; a retained owner prevents
        // ABA and holds the entire actual immutable contiguous mmap, including a
        // different subspan requested by a temporary duplicate pin. Only dropping
        // self frees owners, which Rust forbids while this &self-bound slice lives.
        // Cache eviction cannot remove our Arc owner. No raw pointer escapes.
        Ok(unsafe { std::slice::from_raw_parts(pointer, length) })
    }
}
