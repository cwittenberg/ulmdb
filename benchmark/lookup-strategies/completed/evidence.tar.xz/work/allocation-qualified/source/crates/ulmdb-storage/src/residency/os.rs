use super::LockOps;
use crate::mapping::Mapping;
use std::{io, sync::OnceLock};
pub(crate) fn page_size() -> io::Result<usize> {
    static PAGE: OnceLock<usize> = OnceLock::new();
    let size = *PAGE.get_or_init(system_page_size);
    if size == 0 {
        Err(io::Error::other("system page size unavailable"))
    } else {
        Ok(size)
    }
}
#[cfg(unix)]
#[allow(unsafe_code)]
fn system_page_size() -> usize {
    // SAFETY: sysconf takes a constant POSIX selector, no pointers or borrowed
    // resources. A non-positive result is rejected before page arithmetic.
    let size = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
    usize::try_from(size).unwrap_or(0)
}
#[cfg(not(unix))]
fn system_page_size() -> usize {
    0
}
pub(super) struct OsLocks;
impl LockOps for OsLocks {
    fn lock(&self, mapping: &Mapping) -> io::Result<()> {
        #[cfg(unix)]
        {
            mapping.bytes.lock()
        }
        #[cfg(not(unix))]
        {
            let _ = mapping;
            Err(io::ErrorKind::Unsupported.into())
        }
    }
    fn unlock(&self, mapping: &Mapping) -> io::Result<()> {
        #[cfg(unix)]
        {
            mapping.bytes.unlock()
        }
        #[cfg(not(unix))]
        {
            let _ = mapping;
            Err(io::ErrorKind::Unsupported.into())
        }
    }
}
